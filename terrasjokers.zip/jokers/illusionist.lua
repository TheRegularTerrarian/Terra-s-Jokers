
SMODS.Joker{ --Illusionist
    key = "illusionist",
    config = {
        extra = {
            Random = 1
        }
    },
    loc_txt = {
        ['name'] = 'Illusionist',
        ['text'] = {
            [1] = 'In {C:attention}first played hand{} of the round, when a',
            [2] = 'non-{C:attention}Face{} card is played, {C:attention}enhance{} it to a',
            [3] = 'random {C:attention}Face{} card.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terrasjo_jokers"] = true, ["terrasjo_Coven_Jokers"] = true, ["terrasjo_terras_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Random}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (G.GAME.current_round.hands_played == 0 and not (context.other_card:is_face()) and to_big((card.ability.extra.Random or 0)) == to_big(1)) then
                local scored_card = context.other_card
                G.E_MANAGER:add_event(Event({
                    func = function()
                        
                        assert(SMODS.change_base(scored_card, nil, "11"))
                        card_eval_status_text(scored_card, 'extra', nil, nil, nil, {message = "Illusioned!", colour = G.C.ORANGE})
                        return true
                    end
                }))
                card.ability.extra.Random = pseudorandom('RANGE:1|3', 1, 3)
            elseif (G.GAME.current_round.hands_played == 0 and not (context.other_card:is_face()) and to_big((card.ability.extra.Random or 0)) == to_big(2)) then
                local scored_card = context.other_card
                G.E_MANAGER:add_event(Event({
                    func = function()
                        
                        assert(SMODS.change_base(scored_card, nil, "12"))
                        card_eval_status_text(scored_card, 'extra', nil, nil, nil, {message = "Illusioned!", colour = G.C.ORANGE})
                        return true
                    end
                }))
                card.ability.extra.Random = pseudorandom('RANGE:1|3', 1, 3)
            elseif (G.GAME.current_round.hands_played == 0 and not (context.other_card:is_face()) and to_big((card.ability.extra.Random or 0)) == to_big(3)) then
                local scored_card = context.other_card
                G.E_MANAGER:add_event(Event({
                    func = function()
                        
                        assert(SMODS.change_base(scored_card, nil, "13"))
                        card_eval_status_text(scored_card, 'extra', nil, nil, nil, {message = "Illusioned!", colour = G.C.ORANGE})
                        return true
                    end
                }))
                card.ability.extra.Random = pseudorandom('RANGE:1|3', 1, 3)
            else
                card.ability.extra.Random = pseudorandom('RANGE:1|3', 1, 3)
            end
        end
    end
}