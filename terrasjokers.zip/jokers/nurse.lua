SMODS.Joker{ --Nurse
    key = "nurse",
    config = {
        extra = {
            mult = 10,
            Xmult = 1.5
        }
    },
    loc_txt = {
        ['name'] = 'Nurse',
        ['text'] = {
            [1] = 'If played hand contains only {C:hearts}Hearts{}, gain',
            [2] = '{C:red}+10{} Mult and {X:red,C:white}X1.5{} Mult.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 6,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
                local allMatchSuit = true
                for i, c in ipairs(context.scoring_hand) do
                    if not (c:is_suit("Hearts")) then
                        allMatchSuit = false
                        break
                    end
                end
                
                return allMatchSuit and #context.scoring_hand > 0
                end)() then
                    return {
                        mult = card.ability.extra.mult,
                        extra = {
                        Xmult = card.ability.extra.Xmult
                    }
                }
            end
        end
    end
}