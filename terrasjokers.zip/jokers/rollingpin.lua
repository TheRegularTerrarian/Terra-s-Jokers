SMODS.Joker{ --Rolling Pin
    key = "rollingpin",
    config = {
        extra = {
            Xmult = 2
        }
    },
    loc_txt = {
        ['name'] = 'Rolling Pin',
        ['text'] = {
            [1] = 'When this {C:attention}Joker{} is sold, instantly win the current round.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 7,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.selling_self  then
            G.E_MANAGER:add_event(Event({
            blocking = false,
            func = function()
                if G.STATE == G.STATES.SELECTING_HAND then
                    G.GAME.chips = G.GAME.blind.chips
                    G.STATE = G.STATES.HAND_PLAYED
                    G.STATE_COMPLETE = true
                end_round()
                return true
                end
            end
        }))
        return {
            message = "Flattened!"
        }
    end
    if context.cardarea == G.jokers and context.joker_main  then
        if (function()
            for i = 1, #G.jokers.cards do
                if G.jokers.cards[i].config.center.key == "j_terrasjo_ovenleader" then
                    return true
                    end
                end
                return false
                end)() then
                    return {
                        Xmult = card.ability.extra.Xmult
                    }
                end
            end
        end
}