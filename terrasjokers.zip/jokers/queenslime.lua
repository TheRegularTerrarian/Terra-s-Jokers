
SMODS.Joker{ --Queen Slime
    key = "queenslime",
    config = {
        extra = {
            dollars0 = 6,
            levels0 = 1,
            dollars = 2
        }
    },
    loc_txt = {
        ['name'] = 'Queen Slime',
        ['text'] = {
            [1] = 'Gain {C:gold}$2{} per hand played. If you have',
            [2] = '{C:attention}King Slime{}, gain {C:gold}$6{} and increase the level',
            [3] = 'of first played {C:attention}poker hand{}.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 5,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
                for i, v in pairs(G.jokers.cards) do
                    if v.config.center.key == "j_terrasjo_kingslime" then 
                        return true
                    end
                end
            end)() then
                return {
                    
                    func = function()
                        
                        local current_dollars = G.GAME.dollars
                        local target_dollars = G.GAME.dollars + 6
                        local dollar_value = target_dollars - current_dollars
                        ease_dollars(dollar_value)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(6), colour = G.C.MONEY})
                        return true
                    end
                }
            elseif ((function()
                for i, v in pairs(G.jokers.cards) do
                    if v.config.center.key == "j_terrasjo_kingslime" then 
                        return true
                    end
                end
            end)() and G.GAME.current_round.hands_played == 0) then
                local target_hand = (context.scoring_name or "High Card")
                level_up_hand(card, target_hand, true, 1)
                return {
                    message = localize('k_level_up_ex')
                }
            elseif (function()
                for i, v in pairs(G.jokers.cards) do
                    if v.config.center.key == "j_terrasjo_kingslime" then 
                        return true
                    end
                end
            end)() then
                return {
                    
                    func = function()
                        
                        local current_dollars = G.GAME.dollars
                        local target_dollars = G.GAME.dollars + 2
                        local dollar_value = target_dollars - current_dollars
                        ease_dollars(dollar_value)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(2), colour = G.C.MONEY})
                        return true
                    end
                }
            end
        end
    end
}