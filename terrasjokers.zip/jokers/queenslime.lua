SMODS.Joker{ --Queen Slime
    key = "queenslime",
    config = {
        extra = {
            dollars = 6,
            levels = 1,
            dollars2 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Queen Slime',
        ['text'] = {
            [1] = 'Gain {C:gold}$2{} per hand played. If you have',
            [2] = '{C:attention}King Slime{}, gain {C:gold}$6{} and increase the level',
            [3] = 'of first played {C:attention}poker hand{}.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 6,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
                for i = 1, #G.jokers.cards do
                    if G.jokers.cards[i].config.center.key == "j_terrasjo_kingslime" then
                        return true
                        end
                    end
                    return false
                    end)() then
                        return {
                            dollars = card.ability.extra.dollars
                        }
                    elseif ((function()
                        for i = 1, #G.jokers.cards do
                            if G.jokers.cards[i].config.center.key == "j_terrasjo_kingslime" then
                                return true
                                end
                            end
                            return false
                            end)() and G.GAME.current_round.hands_played == 0) then
                                local target_hand = (context.scoring_name or "High Card")
                                return {
                                    level_up = card.ability.extra.levels,
                                    level_up_hand = target_hand,
                                    message = localize('k_level_up_ex')
                                }
                            elseif (function()
                                for i = 1, #G.jokers.cards do
                                    if G.jokers.cards[i].config.center.key == "j_terrasjo_kingslime" then
                                        return false
                                        end
                                    end
                                    return true
                                    end)() then
                                        return {
                                            dollars = card.ability.extra.dollars2
                                        }
                                    end
                                end
                            end
}