
SMODS.Joker{ --Queen Slime
    key = "queenslime",
    config = {
        extra = {
            levels = 1,
            dollars = 6,
            dollars2 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Queen Slime',
        ['text'] = {
            [1] = 'Gain {C:gold}$2{} per hand played. If you have',
                [2] = '{C:attention}King Slime{}, gain {C:gold}$6{} and increase the level',
                [3] = 'of first played {C:attention}poker hand{}.'
            },
            ['unlock'] = {
                [1] = ''
            }
        },
        pos = {
            x = 6,
            y = 4
        },
        display_size = {
            w = 71 * 1, 
            h = 95 * 1
        },
        cost = 8,
        rarity = 2,
        blueprint_compat = true,
        eternal_compat = true,
        perishable_compat = true,
        unlocked = true,
        discovered = false,
        atlas = 'CustomJokers',
        pools = { ["terrasjo_terras_jokers"] = true },
        
        calculate = function(self, card, context)
            if context.cardarea == G.jokers and context.joker_main  then
                if G.GAME.current_round.hands_played == 0 then
                    local target_hand = (context.scoring_name or "High Card")
                    return {
                        level_up = card.ability.extra.levels,
                        level_up_hand = target_hand,
                        message = localize('k_level_up_ex')
                    }
                else
                    return {
                        
                        func = function()
                            
                            local current_dollars = G.GAME.dollars
                            local target_dollars = G.GAME.dollars + card.ability.extra.dollars
                            local dollar_value = target_dollars - current_dollars
                            ease_dollars(dollar_value)
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.dollars), colour = G.C.MONEY})
                            return true
                        end
                    }
                    return {
                        
                        func = function()
                            
                            local current_dollars = G.GAME.dollars
                            local target_dollars = G.GAME.dollars + card.ability.extra.dollars2
                            local dollar_value = target_dollars - current_dollars
                            ease_dollars(dollar_value)
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.dollars2), colour = G.C.MONEY})
                            return true
                        end
                    }
                end
            end
        end
    }