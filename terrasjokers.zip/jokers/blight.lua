
SMODS.Joker{ --Blight
    key = "blight",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Blight',
        ['text'] = {
            [1] = 'Reduces {C:attention}Rank{} of all played cards by {C:attention}1{}. (Minimum 2)'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terrasjo_jokers"] = true, ["terrasjo_Coven_Jokers"] = true, ["terrasjo_terras_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:get_id() == 14 then
                assert(SMODS.change_base(context.other_card, nil, "King"))
                return {
                    message = "Card Modified!"
                }
            elseif context.other_card:get_id() == 13 then
                assert(SMODS.change_base(context.other_card, nil, "Queen"))
                return {
                    message = "Card Modified!"
                }
            elseif context.other_card:get_id() == 12 then
                assert(SMODS.change_base(context.other_card, nil, "Jack"))
                return {
                    message = "Card Modified!"
                }
            elseif context.other_card:get_id() == 11 then
                assert(SMODS.change_base(context.other_card, nil, "10"))
                return {
                    message = "Card Modified!"
                }
            elseif context.other_card:get_id() == 10 then
                assert(SMODS.change_base(context.other_card, nil, "9"))
                return {
                    message = "Card Modified!"
                }
            elseif context.other_card:get_id() == 9 then
                assert(SMODS.change_base(context.other_card, nil, "8"))
                return {
                    message = "Card Modified!"
                }
            elseif context.other_card:get_id() == 8 then
                assert(SMODS.change_base(context.other_card, nil, "7"))
                return {
                    message = "Card Modified!"
                }
            elseif context.other_card:get_id() == 7 then
                assert(SMODS.change_base(context.other_card, nil, "6"))
                return {
                    message = "Card Modified!"
                }
            elseif context.other_card:get_id() == 6 then
                assert(SMODS.change_base(context.other_card, nil, "5"))
                return {
                    message = "Card Modified!"
                }
            elseif context.other_card:get_id() == 5 then
                assert(SMODS.change_base(context.other_card, nil, "4"))
                return {
                    message = "Card Modified!"
                }
            elseif context.other_card:get_id() == 4 then
                assert(SMODS.change_base(context.other_card, nil, "3"))
                return {
                    message = "Card Modified!"
                }
            elseif context.other_card:get_id() == 3 then
                assert(SMODS.change_base(context.other_card, nil, "2"))
                return {
                    message = "Card Modified!"
                }
            end
        end
    end
}