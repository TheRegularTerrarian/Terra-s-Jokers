SMODS.Joker{ --Blight
    key = "blight",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Blight',
        ['text'] = {
            [1] = 'Reduces {C:attention}Rank{} of all played cards by {C:attention}1{}. (Minimum 2)'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terrasjo_jokers"] = true, ["terrasjo_Coven_Jokers"] = true, ["terrasjo_terras_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:get_id() == 14 then
            elseif context.other_card:get_id() == 13 then
            elseif context.other_card:get_id() == 12 then
            elseif context.other_card:get_id() == 11 then
            elseif context.other_card:get_id() == 10 then
            elseif context.other_card:get_id() == 9 then
            elseif context.other_card:get_id() == 8 then
            elseif context.other_card:get_id() == 7 then
            elseif context.other_card:get_id() == 6 then
            elseif context.other_card:get_id() == 5 then
            elseif context.other_card:get_id() == 4 then
            elseif context.other_card:get_id() == 3 then
            end
        end
    end
}