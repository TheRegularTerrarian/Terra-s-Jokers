
SMODS.Joker{ --Dark Mage
    key = "darkmage",
    config = {
        extra = {
            Xmult = 1.5,
            Xmult2 = 2,
            Xmult3 = 2.5,
            Xmult4 = 3,
            Xmult5 = 3.5,
            Xmult6 = 4,
            respect = 0,
            no = 0,
            start_dissolve = 0,
            eternal = 0
        }
    },
    loc_txt = {
        ['name'] = 'Dark Mage',
        ['text'] = {
            [1] = 'At the start of round, destroy a random {C:attention}Joker{}',
            [2] = 'and create an {C:attention}Old One\'s Skeleton{}. Gain {X:red,C:white}X1.5{} Mult',
            [3] = 'increasing by {X:red,C:white}X0.5{} for each {C:attention}Old One\'s Skeleton{}.'
            },
            ['unlock'] = {
                [1] = ''
            }
        },
        pos = {
            x = 3,
            y = 4
        },
        display_size = {
            w = 71 * 1, 
            h = 95 * 1
        },
        cost = 10,
        rarity = 3,
        blueprint_compat = true,
        eternal_compat = true,
        perishable_compat = true,
        unlocked = true,
        discovered = false,
        atlas = 'CustomJokers',
        pools = { ["terrasjo_terras_jokers"] = true },
        
        calculate = function(self, card, context)
            if context.setting_blind  then
                return {
                    func = function()
                        local destructable_jokers = {}
                        for i, joker in ipairs(G.jokers.cards) do
                            if joker ~= card and not SMODS.is_eternal(joker) and not joker.getting_sliced then
                                table.insert(destructable_jokers, joker)
                            end
                        end
                        local target_joker = #destructable_jokers > 0 and pseudorandom_element(destructable_jokers, pseudoseed('destroy_joker')) or nil
                        
                        if target_joker then
                            target_joker.getting_sliced = true
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                                    return true
                                end
                            }))
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                        end
                        return true
                    end,
                    extra = {
                        func = function()
                            
                            local created_joker = false
                            if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                                created_joker = true
                                G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                                G.E_MANAGER:add_event(Event({
                                    func = function()
                                        local joker_card = SMODS.add_card({ set = 'Joker', key = 'j_terrasjo_oldonesskeleton' })
                                        if joker_card then
                                            
                                            joker_card:add_sticker('eternal', true)
                                        end
                                        G.GAME.joker_buffer = 0
                                        return true
                                    end
                                }))
                            end
                            if created_joker then
                                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_joker'), colour = G.C.BLUE})
                            end
                            return true
                        end,
                        colour = G.C.BLUE
                    }
                }
            end
            if context.cardarea == G.jokers and context.joker_main  then
                if (function()
                    local count = 0
                    for _, joker_owned in pairs(G.jokers.cards or {}) do
                        if joker_owned.config.center.rarity == 1 then
                            count = count + 1
                        end
                    end
                    return to_big(count) == to_big(1)
                end)() then
                    return {
                        Xmult = card.ability.extra.Xmult
                    }
                    elseif (function()
                        local count = 0
                        for _, joker_owned in pairs(G.jokers.cards or {}) do
                            if joker_owned.config.center.rarity == 1 then
                                count = count + 1
                            end
                        end
                        return to_big(count) == to_big(2)
                    end)() then
                        return {
                            Xmult = card.ability.extra.Xmult2
                        }
                        elseif (function()
                            local count = 0
                            for _, joker_owned in pairs(G.jokers.cards or {}) do
                                if joker_owned.config.center.rarity == 1 then
                                    count = count + 1
                                end
                            end
                            return to_big(count) == to_big(3)
                        end)() then
                            return {
                                Xmult = card.ability.extra.Xmult3
                            }
                            elseif (function()
                                local count = 0
                                for _, joker_owned in pairs(G.jokers.cards or {}) do
                                    if joker_owned.config.center.rarity == 1 then
                                        count = count + 1
                                    end
                                end
                                return to_big(count) == to_big(4)
                            end)() then
                                return {
                                    Xmult = card.ability.extra.Xmult4
                                }
                                elseif (function()
                                    local count = 0
                                    for _, joker_owned in pairs(G.jokers.cards or {}) do
                                        if joker_owned.config.center.rarity == 1 then
                                            count = count + 1
                                        end
                                    end
                                    return to_big(count) == to_big(5)
                                end)() then
                                    return {
                                        Xmult = card.ability.extra.Xmult5
                                    }
                                    elseif (function()
                                        local count = 0
                                        for _, joker_owned in pairs(G.jokers.cards or {}) do
                                            if joker_owned.config.center.rarity == 1 then
                                                count = count + 1
                                            end
                                        end
                                        return to_big(count) == to_big(6)
                                    end)() then
                                        return {
                                            Xmult = card.ability.extra.Xmult6
                                        }
                                    end
                                end
                            end
                        }