
SMODS.Joker{ --Witch
    key = "witch",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Witch',
        ['text'] = {
            [1] = 'The {C:attention}Suit{} of all played cards are randomised.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terrasjo_jokers"] = true, ["terrasjo_Coven_Jokers"] = true, ["terrasjo_terras_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {localize((G.GAME.current_round.Spades_card or {}).suit or 'Spades', 'suits_singular'), localize((G.GAME.current_round.Hearts_card or {}).suit or 'Spades', 'suits_singular'), localize((G.GAME.current_round.Diamonds_card or {}).suit or 'Spades', 'suits_singular'), localize((G.GAME.current_round.Clubs_card or {}).suit or 'Spades', 'suits_singular')}, colours = {G.C.SUITS[(G.GAME.current_round.Spades_card or {}).suit or 'Spades'], G.C.SUITS[(G.GAME.current_round.Hearts_card or {}).suit or 'Spades'], G.C.SUITS[(G.GAME.current_round.Diamonds_card or {}).suit or 'Spades'], G.C.SUITS[(G.GAME.current_round.Clubs_card or {}).suit or 'Spades']}}
    end,
    
    set_ability = function(self, card, initial)
        G.GAME.current_round.Spades_card = { suit = 'Spades' }
        G.GAME.current_round.Hearts_card = { suit = 'Hearts' }
        G.GAME.current_round.Diamonds_card = { suit = 'Diamonds' }
        G.GAME.current_round.Clubs_card = { suit = 'Clubs' }
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            local scored_card = context.other_card
            G.E_MANAGER:add_event(Event({
                func = function()
                    
                    assert(SMODS.change_base(scored_card, pseudorandom_element(SMODS.Suits, 'edit_card_suit').key, nil))
                    card_eval_status_text(scored_card, 'extra', nil, nil, nil, {message = "Card Modified!", colour = G.C.ORANGE})
                    return true
                end
            }))
        end
    end
}