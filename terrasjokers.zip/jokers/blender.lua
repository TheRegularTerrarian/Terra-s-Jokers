SMODS.Joker{ --Blender
    key = "blender",
    config = {
        extra = {
            repetitions = 1,
            Xmult = 2
        }
    },
    loc_txt = {
        ['name'] = 'Blender',
        ['text'] = {
            [1] = '{C:attention}Retriggers{} all played {C:attention}Enhanced{} cards.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 2,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
            if (function()
                local enhancements = SMODS.get_enhancements(context.other_card)
                for k, v in pairs(enhancements) do
                    if v then
                        return true
                        end
                    end
                    return false
                    end)() then
                        return {
                            repetitions = card.ability.extra.repetitions,
                        message = "Blending!"
                    }
                end
            end
            if context.cardarea == G.jokers and context.joker_main  then
                if (function()
                    for i = 1, #G.jokers.cards do
                        if G.jokers.cards[i].config.center.key == "j_terrasjo_ovenleader" then
                            return true
                            end
                        end
                        return false
                        end)() then
                            return {
                                Xmult = card.ability.extra.Xmult
                            }
                        end
                    end
                end
}