SMODS.Joker{ --Air Fryer
    key = "airfryer",
    config = {
        extra = {
            pb_mult_9fc1ede5 = 1,
            perma_mult = 0
        }
    },
    loc_txt = {
        ['name'] = 'Air Fryer',
        ['text'] = {
            [1] = 'Scored cards permanently give {C:red}+1{} Mult.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 6,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            context.other_card.ability.perma_mult = context.other_card.ability.perma_mult or 0
            context.other_card.ability.perma_mult = context.other_card.ability.perma_mult + card.ability.extra.pb_mult_9fc1ede5
            return {
                extra = { message = localize('k_upgrade_ex'), colour = G.C.MULT }, card = card
            }
        end
    end
}