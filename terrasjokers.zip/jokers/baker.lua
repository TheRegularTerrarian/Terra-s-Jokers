
SMODS.Joker{ --Baker
    key = "baker",
    config = {
        extra = {
            Pokerhand = 0,
            start_dissolve = 0,
            y = 0,
            no = 0,
            var1 = 0,
            ignore = 0
        }
    },
    loc_txt = {
        ['name'] = 'Baker',
        ['text'] = {
            [1] = 'When a {C:attention}Blind{} is selected, if you have used 10 {C:planet}Planet{}',
            [2] = 'cards with a {C:attention}poker hand{} at Level 5 or higher while',
            [3] = 'owning {C:red}Baker{}, {C:attention}destroy{} self and create {C:red}Famine{}.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terrasjo_jokers"] = true, ["terrasjo_terras_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Pokerhand}}
    end,
    
    calculate = function(self, card, context)
        if context.setting_blind  then
            if to_big((card.ability.extra.Pokerhand or 0)) >= to_big(10) then
                return {
                    func = function()
                        local target_joker = card
                        
                        if target_joker then
                            target_joker.getting_sliced = true
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                                    return true
                                end
                            }))
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Transformed!", colour = G.C.RED})
                        end
                        return true
                    end,
                    extra = {
                        func = function()
                            
                            local created_joker = true
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    local joker_card = SMODS.add_card({ set = 'Joker', key = 'j_terrasjo_famine' })
                                    if joker_card then
                                        joker_card:set_edition(card.ability.extra.e_negative, true)
                                        
                                    end
                                    
                                    return true
                                end
                            }))
                            
                            if created_joker then
                                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_joker'), colour = G.C.BLUE})
                            end
                            return true
                        end,
                        colour = G.C.BLUE
                    }
                }
            end
        end
        if context.using_consumeable  then
            if ((function()
                for hand, data in pairs(G.GAME.hands) do
                    if hand and to_big(data.level) >= to_big(5) then
                        return true
                    end
                end
                return false
            end)() and context.consumeable and context.consumeable.ability.set == 'Planet') then
                return {
                    func = function()
                        card.ability.extra.Pokerhand = (card.ability.extra.Pokerhand) + 1
                        return true
                    end
                }
            end
        end
    end
}