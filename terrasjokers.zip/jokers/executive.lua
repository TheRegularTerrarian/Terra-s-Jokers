
SMODS.Joker{ --Executive
    key = "executive",
    config = {
        extra = {
            dollars0 = 1,
            n = 0
        }
    },
    loc_txt = {
        ['name'] = 'Executive',
        ['text'] = {
            [1] = 'When a {C:planet}Planet{} card is used, gain {C:gold}$1{}.',
            [2] = 'After playing a hand, if all cards played',
            [3] = 'are {C:spades}Spades{} or {C:clubs}Clubs{},',
            [4] = 'create a random {C:planet}Planet{} Card.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 4,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.using_consumeable  then
            if context.consumeable and context.consumeable.ability.set == 'Planet' then
                return {
                    
                    func = function()
                        
                        local current_dollars = G.GAME.dollars
                        local target_dollars = G.GAME.dollars + 1
                        local dollar_value = target_dollars - current_dollars
                        ease_dollars(dollar_value)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(1), colour = G.C.MONEY})
                        return true
                    end
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            if (context.other_card:is_suit("Spades") or context.other_card:is_suit("Clubs") and not (context.other_card:is_suit("Hearts") or context.other_card:is_suit("Diamonds"))) then
                for i = 1, math.min(1, G.consumeables.config.card_limit - #G.consumeables.cards) do
                    G.E_MANAGER:add_event(Event({
                        trigger = 'after',
                        delay = 0.4,
                        func = function()
                            play_sound('timpani')
                            SMODS.add_card({ set = 'Planet', })                            
                            card:juice_up(0.3, 0.5)
                            return true
                        end
                    }))
                end
                delay(0.6)
                return {
                    message = created_consumable and localize('k_plus_planet') or nil
                }
            end
        end
    end
}