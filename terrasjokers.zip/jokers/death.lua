SMODS.Joker{ --Death
    key = "death",
    config = {
        extra = {
            Souls = 0,
            shatter = 0,
            y = 0,
            no = 0,
            var1 = 0
        }
    },
    loc_txt = {
        ['name'] = 'Death',
        ['text'] = {
            [1] = 'You win. Disappears after winning 7 rounds.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terrasjo_jokers"] = true },
    in_pool = function(self, args)
          return (
          not args 
          or args.source ~= 'sho' and args.source ~= 'buf' and args.source ~= 'jud' and args.source ~= 'rta' and args.source ~= 'wra' 
          or args.source == 'rif' or args.source == 'sou' or args.source == 'uta'
          )
          and true
      end,

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                func = function()
                    G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.5,
                    func = function()
                        G.GAME.chips = G.GAME.blind.chips
                        G.STATE = G.STATES.HAND_PLAYED
                        G.STATE_COMPLETE = true
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Apocalypse!", colour = G.C.RED})
                        return true
                        end,
                    }))
                    
                    return true
                    end
                }
            end
            if context.setting_blind  then
                if (card.ability.extra.Souls or 0) >= 7 then
                    return {
                        func = function()
                            local destructable_jokers = {}
                            for i, joker in ipairs(G.jokers.cards) do
                                if joker ~= card and not SMODS.is_eternal(joker) and not joker.getting_sliced then
                                    table.insert(destructable_jokers, joker)
                                end
                            end
                            local target_joker = #destructable_jokers > 0 and pseudorandom_element(destructable_jokers, pseudoseed('destroy_joker')) or nil
                            
                            if target_joker then
                                target_joker.getting_sliced = true
                                G.E_MANAGER:add_event(Event({
                                func = function()
                                    target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                                    return true
                                    end
                                }))
                                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Death has left the town in victory!", colour = G.C.RED})
                            end
                            return true
                            end
                        }
                    else
                        return {
                            func = function()
                                card.ability.extra.Souls = (card.ability.extra.Souls) + 1
                                return true
                                end
                            }
                        end
                    end
                end
}