SMODS.Joker{ --Death
    key = "death",
    config = {
        extra = {
            Souls = 0,
            shatter = 0,
            y = 0
        }
    },
    loc_txt = {
        ['name'] = 'Death',
        ['text'] = {
            [1] = 'You win. Disappears after winning 7 rounds.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terrasjo_jokers"] = true },
    in_pool = function(self, args)
          return (
          not args 
          or args.source ~= 'sho' and args.source ~= 'buf' and args.source ~= 'jud' and args.source ~= 'rta' and args.source ~= 'wra' 
          or args.source == 'rif' or args.source == 'sou' or args.source == 'uta'
          )
          and true
      end,

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            G.E_MANAGER:add_event(Event({
            blocking = false,
            func = function()
                if G.STATE == G.STATES.SELECTING_HAND then
                    G.GAME.chips = G.GAME.blind.chips
                    G.STATE = G.STATES.HAND_PLAYED
                    G.STATE_COMPLETE = true
                end_round()
                return true
                end
            end
        }))
        return {
            message = "Apocalypse!"
        }
    end
    if context.setting_blind  then
        if (card.ability.extra.Souls or 0) >= 7 then
            return {
                func = function()
                    card:shatter()
                    return true
                    end,
                    message = "Death has left the town in victory!"
                }
            else
                return {
                    func = function()
                        card.ability.extra.Souls = (card.ability.extra.Souls) + 1
                        return true
                        end
                    }
                end
            end
        end
}