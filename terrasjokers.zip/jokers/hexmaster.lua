
SMODS.Joker{ --Hex Master
    key = "hexmaster",
    config = {
        extra = {
            xchips0 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Hex Master',
        ['text'] = {
            [1] = 'After playing a hand, create 1 {C:attention}Hierophant{}.',
            [2] = 'If you have {C:attention}22{} or more {C:attention}Bonus Cards{} in',
            [3] = 'your deck, gain {X:blue,C:white}X2{} Chips.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terrasjo_jokers"] = true, ["terrasjo_Coven_Jokers"] = true, ["terrasjo_terras_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
                local count = 0
                for _, playing_card in pairs(G.playing_cards or {}) do
                    if SMODS.get_enhancements(playing_card)["m_bonus"] == true then
                        count = count + 1
                    end
                end
                return to_big(count) >= to_big(22)
            end)() then
                return {
                    x_chips = 2,
                    message = "Hex Bomb!"
                }
            else
                for i = 1, math.min(1, G.consumeables.config.card_limit - #G.consumeables.cards) do
                    G.E_MANAGER:add_event(Event({
                        trigger = 'after',
                        delay = 0.4,
                        func = function()
                            play_sound('timpani')
                            SMODS.add_card({ set = 'Tarot', key = 'c_heirophant'})                            
                            card:juice_up(0.3, 0.5)
                            return true
                        end
                    }))
                end
                delay(0.6)
                return {
                    message = "Hexed!"
                }
            end
        end
    end
}