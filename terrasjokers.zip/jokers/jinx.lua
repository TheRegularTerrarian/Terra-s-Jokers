SMODS.Joker{ --Jinx
    key = "jinx",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Jinx',
        ['text'] = {
            [1] = 'If played hand contains 2 cards, {C:attention}destroy{} both.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terrasjo_jokers"] = true, ["terrasjo_Coven_Jokers"] = true, ["terrasjo_terras_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.destroy_card and context.destroy_card.should_destroy  then
            return { remove = true }
        end
        if context.individual and context.cardarea == G.play  then
            context.other_card.should_destroy = false
            if #context.scoring_hand == 2 then
                context.other_card.should_destroy = true
                return {
                    message = "Jinxed!"
                }
            end
        end
    end
}