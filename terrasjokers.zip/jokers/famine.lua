SMODS.Joker{ --Famine
    key = "famine",
    config = {
        extra = {
            Chips = 0,
            Mult = 0,
            XMult = 1
        }
    },
    loc_txt = {
        ['name'] = 'Famine',
        ['text'] = {
            [1] = 'When a {C:attention}Blind{} is selected, permanently give',
            [2] = '{C:blue}+100{} Chips, {C:red}+10{} Mult and {X:red,C:white}X0.5{} Mult.',
            [3] = '{C:inactive}(Currently{} {C:blue}+#1#{} {C:inactive}Chips){} {C:inactive}(Currently{} {C:red}+#2#{} {C:inactive}Mult){}',
            [4] = '{C:inactive}(Currently{} {X:red,C:white}#3#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terrasjo_jokers"] = true },
    in_pool = function(self, args)
          return (
          not args 
          or args.source ~= 'sho' and args.source ~= 'buf' and args.source ~= 'jud' and args.source ~= 'rta' and args.source ~= 'wra' 
          or args.source == 'rif' or args.source == 'sou' or args.source == 'uta'
          )
          and true
      end,

    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Chips, card.ability.extra.Mult, card.ability.extra.XMult}}
    end,

    
    calculate = function(self, card, context)
        if context.setting_blind  then
            return {
                func = function()
                    card.ability.extra.Chips = (card.ability.extra.Chips) + 100
                    return true
                    end,
                    extra = {
                    func = function()
                        card.ability.extra.Mult = (card.ability.extra.Mult) + 10
                        return true
                        end,
                        colour = G.C.GREEN,
                        extra = {
                        func = function()
                            card.ability.extra.XMult = (card.ability.extra.XMult) + 0.5
                            return true
                            end,
                            colour = G.C.GREEN
                        }
                    }
                }
            end
            if context.cardarea == G.jokers and context.joker_main  then
                return {
                    chips = card.ability.extra.Chips,
                    message = "Starving!",
                    extra = {
                    mult = card.ability.extra.Mult,
                    extra = {
                    Xmult = card.ability.extra.XMult
                }
            }
        }
    end
end
}