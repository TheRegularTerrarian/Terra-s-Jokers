
SMODS.Joker{ --Suppressor
    key = "suppressor",
    config = {
        extra = {
            n = 0
        }
    },
    loc_txt = {
        ['name'] = 'Suppressor',
        ['text'] = {
            [1] = 'If the {C:attention}first discard{} of the round',
            [2] = 'contains {C:attention}2{} cards, destroy them.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 0,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.discard  then
            if (to_big(#context.full_hand) == to_big(2) and G.GAME.current_round.discards_used <= 0) then
                return {
                    remove = true,
                    message = "Suppressed!"
                }
            end
        end
    end
}