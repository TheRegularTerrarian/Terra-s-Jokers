
SMODS.Joker{ --Meloetta (Aria)
    key = "meloetta",
    config = {
        extra = {
            levels = 3,
            levels2 = 3
        }
    },
    loc_txt = {
        ['name'] = 'Meloetta (Aria)',
        ['text'] = {
            [1] = 'When a {C:blue}hand{} is played or discarded, level up {C:orange}poker hand{} 3 times.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 1,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' 
            or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            local target_hand = (context.scoring_name or "High Card")
            return {
                level_up = card.ability.extra.levels,
                level_up_hand = target_hand,
                message = localize('k_level_up_ex')
            }
        end
        if context.pre_discard  then
            local text, poker_hands, text_disp, loc_disp_text = G.FUNCS.get_poker_hand_info(G.hand.highlighted)
            local target_hand2 = text
            return {
                level_up = card.ability.extra.levels2,
                level_up_hand = target_hand2,
                message = localize('k_level_up_ex')
            }
        end
    end
}