SMODS.Joker{ --Saboteur
    key = "saboteur",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Saboteur',
        ['text'] = {
            [1] = 'Disables all {C:attention}Boss Blinds{}. Always has {C:attention}Perishable{}.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 8,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },

    set_ability = function(self, card, initial)
        card:add_sticker('perishable', true)
    end,

    
    calculate = function(self, card, context)
        if context.setting_blind  then
            if G.GAME.blind.boss then
                return {
                    func = function()
                        if G.GAME.blind and G.GAME.blind.boss and not G.GAME.blind.disabled then
                            G.E_MANAGER:add_event(Event({
                            func = function()
                                G.GAME.blind:disable()
                                play_sound('timpani')
                                return true
                                end
                            }))
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Sabotaged!", colour = G.C.GREEN})
                        end
                        return true
                        end
                    }
                end
            end
        end
}