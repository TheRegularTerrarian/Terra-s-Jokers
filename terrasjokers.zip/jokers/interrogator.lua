
SMODS.Joker{ --Interrogator
    key = "interrogator",
    config = {
        extra = {
            dollars = 1,
            discards = 1,
            round = 0
        }
    },
    loc_txt = {
        ['name'] = 'Interrogator',
        ['text'] = {
            [1] = 'When a {C:attention}Blind{} is selected, if you have {C:gold}$25{} or less,',
            [2] = 'gain {C:attention}+1{} {C:red}discard{}. Gains {C:gold}$1{} for each card discarded.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 5,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.discard  then
            return {
                
                func = function()
                    
                    local current_dollars = G.GAME.dollars
                    local target_dollars = G.GAME.dollars + card.ability.extra.dollars
                    local dollar_value = target_dollars - current_dollars
                    ease_dollars(dollar_value)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.dollars), colour = G.C.MONEY})
                    return true
                end
            }
        end
        if context.setting_blind  then
            if to_big(G.GAME.dollars) <= to_big(25) then
                return {
                    
                    func = function()
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.discards).." Discards", colour = G.C.GREEN})
                        
                        G.GAME.current_round.discards_left = G.GAME.current_round.discards_left + card.ability.extra.discards
                        return true
                    end
                }
            end
        end
    end
}