SMODS.Joker{ --Caterer
    key = "caterer",
    config = {
        extra = {
            n = 0,
            y = 0
        }
    },
    loc_txt = {
        ['name'] = 'Caterer',
        ['text'] = {
            [1] = 'If {C:attention}played hand{} contains {C:attention}5{} scoring',
            [2] = '{C:attention}face cards{}, create a random {C:attention}Consumable{}.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 0,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if ((function()
                local allMatchRank = true
                for i, c in ipairs(context.scoring_hand) do
                    if not (c:is_face()) then
                        allMatchRank = false
                        break
                    end
                end
                
                return allMatchRank and #context.scoring_hand > 0
                end)() and #context.scoring_hand == 5) then
                    for i = 1, math.min(1, G.consumeables.config.card_limit - #G.consumeables.cards) do
                        G.E_MANAGER:add_event(Event({
                        trigger = 'after',
                        delay = 0.4,
                        func = function()
                            play_sound('timpani')
                            local sets = {'Tarot', 'Planet', 'Spectral'}
                            local random_set = pseudorandom_element(sets, 'random_consumable_set')
                            SMODS.add_card({ set = random_set, soulable = true, })                            
                            card:juice_up(0.3, 0.5)
                            return true
                            end
                        }))
                    end
                    delay(0.6)
                    return {
                        message = "Served!"
                    }
                end
            end
        end
}