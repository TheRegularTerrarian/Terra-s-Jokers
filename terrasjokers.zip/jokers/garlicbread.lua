SMODS.Joker{ --Garlic Bread
    key = "garlicbread",
    config = {
        extra = {
            consumable_slots = 2,
            discards = 1,
            hands = 1,
            Xmult = 2,
            permanent = 0
        }
    },
    loc_txt = {
        ['name'] = 'Garlic Bread',
        ['text'] = {
            [1] = 'When sold, gain +2 {C:attention}Consumable{} slots but lose 1 {C:blue}Hand{} and {C:red}discard{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 4,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.selling_self  then
            return {
                func = function()
                    G.E_MANAGER:add_event(Event({func = function()
                        G.consumeables.config.card_limit = G.consumeables.config.card_limit + card.ability.extra.consumable_slots
                        return true
                        end }))
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.consumable_slots).." Consumable Slot", colour = G.C.GREEN})
                        return true
                        end,
                        extra = {
                        func = function()
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(card.ability.extra.discards).." Discard", colour = G.C.RED})
                            
                            G.GAME.round_resets.discards = G.GAME.round_resets.discards - card.ability.extra.discards
                            ease_discard(-card.ability.extra.discards)
                            
                            return true
                            end,
                            colour = G.C.ORANGE,
                            extra = {
                            func = function()
                                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(card.ability.extra.hands).." Hand", colour = G.C.RED})
                                
                                G.GAME.round_resets.hands = G.GAME.round_resets.hands - card.ability.extra.hands
                                ease_hands_played(-card.ability.extra.hands)
                                
                                return true
                                end,
                                colour = G.C.GREEN
                            }
                        }
                    }
                end
                if context.cardarea == G.jokers and context.joker_main  then
                    if (function()
                        for i = 1, #G.jokers.cards do
                            if G.jokers.cards[i].config.center.key == "j_terrasjo_ovenleader" then
                                return true
                                end
                            end
                            return false
                            end)() then
                                return {
                                    Xmult = card.ability.extra.Xmult
                                }
                            end
                        end
                    end
}