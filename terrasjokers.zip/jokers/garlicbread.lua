
SMODS.Joker{ --Garlic Bread
    key = "garlicbread",
    config = {
        extra = {
            consumable_slots0 = 2,
            discards0 = 1,
            hands0 = 1,
            xmult0 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Garlic Bread',
        ['text'] = {
            [1] = 'When sold, gain +2 {C:attention}Consumable{} slots but lose 1 {C:blue}Hand{} and {C:red}discard{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 4,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = false,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.selling_self  then
            return {
                func = function()
                    G.E_MANAGER:add_event(Event({func = function()
                        G.consumeables.config.card_limit = G.consumeables.config.card_limit + 2
                        return true
                    end }))
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(2).." Consumable Slot", colour = G.C.GREEN})
                    return true
                end,
                extra = {
                    
                    func = function()
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(1).." Discards", colour = G.C.RED})
                        
                        G.GAME.round_resets.discards = G.GAME.round_resets.discards - 1
                        ease_discard(-1)
                        
                        return true
                    end,
                    colour = G.C.GREEN,
                    extra = {
                        
                        func = function()
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(1).." Hands", colour = G.C.RED})
                            
                            G.GAME.round_resets.hands = G.GAME.round_resets.hands - 1
                            ease_hands_played(-1)
                            
                            return true
                        end,
                        colour = G.C.GREEN
                    }
                }
            }
        end
        if context.cardarea == G.jokers and context.joker_main  then
            if to_big(#G.jokers.highlighted) == to_big(1) then
                return {
                    Xmult = 2
                }
            end
        end
    end
}