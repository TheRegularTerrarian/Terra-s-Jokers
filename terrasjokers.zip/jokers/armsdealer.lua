
SMODS.Joker{ --Arms Dealer
    key = "armsdealer",
    config = {
        extra = {
            dollars0 = 7
        }
    },
    loc_txt = {
        ['name'] = 'Arms Dealer',
        ['text'] = {
            [1] = 'If played hand contains {C:attention}1{} scoring card,',
            [2] = 'enhance it to a {C:attention}Glass Card{}.',
            [3] = 'When a {C:attention}Glass Card{} breaks, gain {C:gold}$7{}.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 3,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if to_big(#context.scoring_hand) == to_big(1) then
                local scored_card = context.other_card
                G.E_MANAGER:add_event(Event({
                    func = function()
                        
                        scored_card:set_ability(G.P_CENTERS.m_glass)
                        card_eval_status_text(scored_card, 'extra', nil, nil, nil, {message = "Armed!", colour = G.C.ORANGE})
                        return true
                    end
                }))
            end
        end
        if context.remove_playing_cards  then
            if (function()
                for k, removed_card in ipairs(context.removed) do
                    if removed_card.shattered then
                        return true
                    end
                end
                return false
            end)() then
                return {
                    
                    func = function()
                        
                        local current_dollars = G.GAME.dollars
                        local target_dollars = G.GAME.dollars + 7
                        local dollar_value = target_dollars - current_dollars
                        ease_dollars(dollar_value)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(7), colour = G.C.MONEY})
                        return true
                    end
                }
            end
        end
    end
}