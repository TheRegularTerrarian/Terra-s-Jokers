SMODS.Joker{ --Arms Dealer
    key = "armsdealer",
    config = {
        extra = {
            dollars = 7
        }
    },
    loc_txt = {
        ['name'] = 'Arms Dealer',
        ['text'] = {
            [1] = 'If played hand contains {C:attention}1{} scoring card,',
            [2] = 'enhance it to a {C:attention}Glass Card{}.',
            [3] = 'When a {C:attention}Glass Card{} breaks, gain {C:gold}$7{}.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 3,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if #context.scoring_hand == 1 then
                context.other_card:set_ability(G.P_CENTERS.m_glass)
                return {
                    message = "Armed!"
                }
            end
        end
        if context.remove_playing_cards  then
            if (function()
                for k, removed_card in ipairs(context.removed) do
                    if removed_card.shattered then
                        return true
                        end
                    end
                    return false
                    end)() then
                        return {
                            dollars = card.ability.extra.dollars
                        }
                    end
                end
            end
}