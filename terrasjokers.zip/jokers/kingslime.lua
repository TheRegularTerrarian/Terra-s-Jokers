
SMODS.Joker{ --King Slime
    key = "kingslime",
    config = {
        extra = {
            chips0 = 200,
            consumable_slots0 = 3,
            chips = 100,
            consumable_slots = 1
        }
    },
    loc_txt = {
        ['name'] = 'King Slime',
        ['text'] = {
            [1] = '{C:blue}+200{} Chips and sets {C:attention}Consumable Slots{} to {C:attention}3{}',
            [2] = 'if you have {C:attention}Queen Slime{}. If not, {C:blue}+100{} Chips',
            [3] = 'and sets {C:attention}Consumable Slots{} to {C:attention}1{}.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 4,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
                for i, v in pairs(G.jokers.cards) do
                    if v.config.center.key == "j_terrasjo_queenslime" then 
                        return true
                    end
                end
            end)() then
                return {
                    chips = 200,
                    extra = {
                        func = function()
                            G.E_MANAGER:add_event(Event({func = function()
                                G.consumeables.config.card_limit = 3
                                return true
                            end }))
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Slimed!", colour = G.C.BLUE})
                            return true
                        end,
                        colour = G.C.GREEN
                    }
                }
            elseif (function()
                for i, v in pairs(G.jokers.cards) do
                    if v.config.center.key == "j_terrasjo_queenslime" then 
                        return true
                    end
                end
            end)() then
                return {
                    chips = 100
                }
            end
        end
        if context.setting_blind  then
            if (function()
                for i, v in pairs(G.jokers.cards) do
                    if v.config.center.key == "j_terrasjo_queenslime" then 
                        return true
                    end
                end
            end)() then
                return {
                    func = function()
                        G.E_MANAGER:add_event(Event({func = function()
                            G.consumeables.config.card_limit = 1
                            return true
                        end }))
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Slimed!", colour = G.C.BLUE})
                        return true
                    end
                }
            end
        end
    end
}