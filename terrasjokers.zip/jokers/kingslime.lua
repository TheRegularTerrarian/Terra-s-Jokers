
SMODS.Joker{ --King Slime
    key = "kingslime",
    config = {
        extra = {
            chips = 200,
            consumable_slots = 3,
            chips2 = 100,
            consumable_slots2 = 1
        }
    },
    loc_txt = {
        ['name'] = 'King Slime',
        ['text'] = {
            [1] = '{C:blue}+200{} Chips and sets {C:attention}Consumable Slots{} to {C:attention}3{}',
            [2] = 'if you have {C:attention}Queen Slime{}. If not, {C:blue}+100{} Chips',
                [3] = 'and sets {C:attention}Consumable Slots{} to {C:attention}1{}.'
            },
            ['unlock'] = {
                [1] = ''
            }
        },
        pos = {
            x = 5,
            y = 4
        },
        display_size = {
            w = 71 * 1, 
            h = 95 * 1
        },
        cost = 6,
        rarity = 2,
        blueprint_compat = true,
        eternal_compat = true,
        perishable_compat = true,
        unlocked = true,
        discovered = false,
        atlas = 'CustomJokers',
        pools = { ["terrasjo_terras_jokers"] = true },
        
        calculate = function(self, card, context)
            if context.cardarea == G.jokers and context.joker_main  then
                return {
                    chips = card.ability.extra.chips,
                    extra = {
                        func = function()
                            G.E_MANAGER:add_event(Event({func = function()
                                G.consumeables.config.card_limit = card.ability.extra.consumable_slots
                                return true
                            end }))
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Slimed!", colour = G.C.BLUE})
                            return true
                        end,
                        colour = G.C.GREEN
                    }
                }
                return {
                    chips = card.ability.extra.chips2
                }
            end
            if context.setting_blind  then
                return {
                    func = function()
                        G.E_MANAGER:add_event(Event({func = function()
                            G.consumeables.config.card_limit = card.ability.extra.consumable_slots2
                            return true
                        end }))
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Slimed!", colour = G.C.BLUE})
                        return true
                    end
                }
            end
        end
    }