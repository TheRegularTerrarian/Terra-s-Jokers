SMODS.Joker{ --Dye Trader
    key = "dyetrader",
    config = {
        extra = {
            deck = 0
        }
    },
    loc_txt = {
        ['name'] = 'Dye Trader',
        ['text'] = {
            [1] = 'If played {C:attention}poker hand{} contains only one suit, add a random',
            [2] = '{C:attention}Enhanced{} card to your deck based on the suit.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 8,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
                local allMatchSuit = true
                for i, c in ipairs(context.full_hand) do
                    if not (c:is_suit("Spades")) then
                        allMatchSuit = false
                        break
                    end
                end
                
                return allMatchSuit and #context.full_hand > 0
                end)() then
                elseif (function()
                    local allMatchSuit = true
                    for i, c in ipairs(context.full_hand) do
                        if not (c:is_suit("Clubs")) then
                            allMatchSuit = false
                            break
                        end
                    end
                    
                    return allMatchSuit and #context.full_hand > 0
                    end)() then
                    elseif (function()
                        local allMatchSuit = true
                        for i, c in ipairs(context.full_hand) do
                            if not (c:is_suit("Diamonds")) then
                                allMatchSuit = false
                                break
                            end
                        end
                        
                        return allMatchSuit and #context.full_hand > 0
                        end)() then
                        elseif (function()
                            local allMatchSuit = true
                            for i, c in ipairs(context.full_hand) do
                                if not (c:is_suit("Hearts")) then
                                    allMatchSuit = false
                                    break
                                end
                            end
                            
                            return allMatchSuit and #context.full_hand > 0
                            end)() then
                            end
                        end
                    end
}