SMODS.Joker{ --Dye Trader
    key = "dyetrader",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Dye Trader',
        ['text'] = {
            [1] = 'If played {C:attention}poker hand{} contains only one suit, add a random',
            [2] = '{C:attention}Enhanced{} card to your deck based on the suit.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 8,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
                local allMatchSuit = true
                for i, c in ipairs(context.full_hand) do
                    if not (c:is_suit("Spades")) then
                        allMatchSuit = false
                        break
                    end
                end
                
                return allMatchSuit and #context.full_hand > 0
                end)() then
                    local card_front = pseudorandom_element(G.P_CARDS, pseudoseed('add_card_hand'))
                    local base_card = create_playing_card({
                    front = card_front,
                    center = 
                    G.P_CENTERS.m_bonus
                }, G.discard, true, false, nil, true)
                
                G.playing_card = (G.playing_card and G.playing_card + 1) or 1
                local new_card = copy_card(base_card, nil, nil, G.playing_card)
                new_card:add_to_deck()
                G.deck.config.card_limit = G.deck.config.card_limit + 1
                G.deck:emplace(new_card)
                table.insert(G.playing_cards, new_card)
                
                base_card:remove()
                
                G.E_MANAGER:add_event(Event({
                func = function() 
                    new_card:start_materialize()
                    return true
                    end
                }))
                return {
                    message = "Added Card!"
                }
            elseif (function()
                local allMatchSuit = true
                for i, c in ipairs(context.full_hand) do
                    if not (c:is_suit("Clubs")) then
                        allMatchSuit = false
                        break
                    end
                end
                
                return allMatchSuit and #context.full_hand > 0
                end)() then
                    local card_front = pseudorandom_element(G.P_CARDS, pseudoseed('add_card_hand'))
                    local base_card = create_playing_card({
                    front = card_front,
                    center = 
                    G.P_CENTERS.m_wild
                }, G.discard, true, false, nil, true)
                
                G.playing_card = (G.playing_card and G.playing_card + 1) or 1
                local new_card = copy_card(base_card, nil, nil, G.playing_card)
                new_card:add_to_deck()
                G.deck.config.card_limit = G.deck.config.card_limit + 1
                G.deck:emplace(new_card)
                table.insert(G.playing_cards, new_card)
                
                base_card:remove()
                
                G.E_MANAGER:add_event(Event({
                func = function() 
                    new_card:start_materialize()
                    return true
                    end
                }))
                return {
                    message = "Added Card!"
                }
            elseif (function()
                local allMatchSuit = true
                for i, c in ipairs(context.full_hand) do
                    if not (c:is_suit("Diamonds")) then
                        allMatchSuit = false
                        break
                    end
                end
                
                return allMatchSuit and #context.full_hand > 0
                end)() then
                    local card_front = pseudorandom_element(G.P_CARDS, pseudoseed('add_card_hand'))
                    local base_card = create_playing_card({
                    front = card_front,
                    center = 
                    G.P_CENTERS.m_gold
                }, G.discard, true, false, nil, true)
                
                G.playing_card = (G.playing_card and G.playing_card + 1) or 1
                local new_card = copy_card(base_card, nil, nil, G.playing_card)
                new_card:add_to_deck()
                G.deck.config.card_limit = G.deck.config.card_limit + 1
                G.deck:emplace(new_card)
                table.insert(G.playing_cards, new_card)
                
                base_card:remove()
                
                G.E_MANAGER:add_event(Event({
                func = function() 
                    new_card:start_materialize()
                    return true
                    end
                }))
                return {
                    message = "Added Card!"
                }
            elseif (function()
                local allMatchSuit = true
                for i, c in ipairs(context.full_hand) do
                    if not (c:is_suit("Hearts")) then
                        allMatchSuit = false
                        break
                    end
                end
                
                return allMatchSuit and #context.full_hand > 0
                end)() then
                    local card_front = pseudorandom_element(G.P_CARDS, pseudoseed('add_card_hand'))
                    local base_card = create_playing_card({
                    front = card_front,
                    center = 
                    G.P_CENTERS.m_mult
                }, G.discard, true, false, nil, true)
                
                G.playing_card = (G.playing_card and G.playing_card + 1) or 1
                local new_card = copy_card(base_card, nil, nil, G.playing_card)
                new_card:add_to_deck()
                G.deck.config.card_limit = G.deck.config.card_limit + 1
                G.deck:emplace(new_card)
                table.insert(G.playing_cards, new_card)
                
                base_card:remove()
                
                G.E_MANAGER:add_event(Event({
                func = function() 
                    new_card:start_materialize()
                    return true
                    end
                }))
                return {
                    message = "Added Card!"
                }
            end
        end
    end
}