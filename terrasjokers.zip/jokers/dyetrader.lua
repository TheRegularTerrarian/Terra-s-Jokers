SMODS.Joker{ --Dye Trader
    key = "dyetrader",
    config = {
        extra = {
            n = 0
        }
    },
    loc_txt = {
        ['name'] = 'Dye Trader',
        ['text'] = {
            [1] = 'If played {C:attention}poker hand{} contains only one',
            [2] = 'suit, create two Dyes based on the suit.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 8,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
                local allMatchSuit = true
                for i, c in ipairs(context.full_hand) do
                    if not (c:is_suit("Spades")) then
                        allMatchSuit = false
                        break
                    end
                end
                
                return allMatchSuit and #context.full_hand > 0
                end)() then
                    for i = 1, math.min(2, G.consumeables.config.card_limit - #G.consumeables.cards) do
                        G.E_MANAGER:add_event(Event({
                        trigger = 'after',
                        delay = 0.4,
                        func = function()
                            play_sound('timpani')
                            SMODS.add_card({ set = 'Tarot', key = 'c_terrasjo_bluedye'})                            
                            card:juice_up(0.3, 0.5)
                            return true
                            end
                        }))
                    end
                    delay(0.6)
                    return {
                        message = created_consumable and localize('k_plus_tarot') or nil
                    }
                elseif (function()
                    local allMatchSuit = true
                    for i, c in ipairs(context.full_hand) do
                        if not (c:is_suit("Clubs")) then
                            allMatchSuit = false
                            break
                        end
                    end
                    
                    return allMatchSuit and #context.full_hand > 0
                    end)() then
                        for i = 1, math.min(2, G.consumeables.config.card_limit - #G.consumeables.cards) do
                            G.E_MANAGER:add_event(Event({
                            trigger = 'after',
                            delay = 0.4,
                            func = function()
                                play_sound('timpani')
                            SMODS.add_card({ set = 'Tarot', key = 'c_terrasjo_greendye'})                            
                            card:juice_up(0.3, 0.5)
                            return true
                            end
                        }))
                    end
                    delay(0.6)
                    return {
                        message = created_consumable and localize('k_plus_tarot') or nil
                    }
                elseif (function()
                    local allMatchSuit = true
                    for i, c in ipairs(context.full_hand) do
                        if not (c:is_suit("Diamonds")) then
                            allMatchSuit = false
                            break
                        end
                    end
                    
                    return allMatchSuit and #context.full_hand > 0
                    end)() then
                        for i = 1, math.min(2, G.consumeables.config.card_limit - #G.consumeables.cards) do
                            G.E_MANAGER:add_event(Event({
                            trigger = 'after',
                            delay = 0.4,
                            func = function()
                                play_sound('timpani')
                                SMODS.add_card({ set = 'Tarot', key = 'c_terrasjo_yellowdye'})                            
                                card:juice_up(0.3, 0.5)
                                return true
                                end
                            }))
                        end
                        delay(0.6)
                        return {
                            message = created_consumable and localize('k_plus_tarot') or nil
                        }
                    elseif (function()
                        local allMatchSuit = true
                        for i, c in ipairs(context.full_hand) do
                            if not (c:is_suit("Hearts")) then
                                allMatchSuit = false
                                break
                            end
                        end
                        
                        return allMatchSuit and #context.full_hand > 0
                        end)() then
                            for i = 1, math.min(2, G.consumeables.config.card_limit - #G.consumeables.cards) do
                                G.E_MANAGER:add_event(Event({
                                trigger = 'after',
                                delay = 0.4,
                                func = function()
                                    play_sound('timpani')
                                    SMODS.add_card({ set = 'Tarot', key = 'c_terrasjo_reddye'})                            
                                    card:juice_up(0.3, 0.5)
                                    return true
                                    end
                                }))
                            end
                            delay(0.6)
                            return {
                                message = created_consumable and localize('k_plus_tarot') or nil
                            }
                        end
                    end
                end
}