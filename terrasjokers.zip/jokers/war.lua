
SMODS.Joker{ --War
    key = "war",
    config = {
        extra = {
            xchips = 3,
            Xmult = 10,
            n = 0
        }
    },
    loc_txt = {
        ['name'] = 'War',
        ['text'] = {
            [1] = 'If you have more than {C:attention}1{} card, {C:attention}destroy{} all scored',
            [2] = 'and discarded cards. If you only have {C:attention}1{} card,',
            [3] = 'gain {X:blue,C:white}X3{} Chips and {X:red,C:white}X10{} Mult when playing a hand.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terrasjo_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' and args.source ~= 'buf' and args.source ~= 'jud' and args.source ~= 'rta' and args.source ~= 'wra' 
            or args.source == 'rif' or args.source == 'sou' or args.source == 'uta'
        )
        and true
    end,
    
    calculate = function(self, card, context)
        if context.destroy_card and context.destroy_card.should_destroy  then
            return { remove = true }
        end
        if context.individual and context.cardarea == G.play  then
            context.other_card.should_destroy = false
            if (function()
                local count = 0
                for _, playing_card in pairs(G.playing_cards or {}) do
                    if true then
                        count = count + 1
                    end
                end
                return to_big(count) >= to_big(2)
            end)() then
                context.other_card.should_destroy = true
                return {
                    message = "Sieged!"
                }
            end
        end
        if context.discard  then
            if (function()
                local count = 0
                for _, playing_card in pairs(G.playing_cards or {}) do
                    if true then
                        count = count + 1
                    end
                end
                return to_big(count) >= to_big(2)
            end)() then
                return {
                    remove = true,
                    message = "Destroyed!"
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
                local count = 0
                for _, playing_card in pairs(G.playing_cards or {}) do
                    if true then
                        count = count + 1
                    end
                end
                return to_big(count) == to_big(1)
            end)() then
                return {
                    x_chips = 3,
                    extra = {
                        Xmult = 10
                    }
                }
            end
        end
    end
}