
SMODS.Joker{ --Oven Leader
    key = "ovenleader",
    config = {
        extra = {
            Xmult = 2,
            Xmult2 = 2,
            Xmult3 = 2,
            Xmult4 = 2,
            Xmult5 = 2,
            Xmult6 = 2,
            Xmult7 = 2,
            Xmult8 = 2,
            Xmult9 = 2,
            Xmult10 = 2,
            Xmult11 = 2,
            Xmult12 = 2,
            Xmult13 = 2,
            Xmult14 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Oven Leader',
        ['text'] = {
            [1] = 'Gain {X:red,C:white}X2{} Mult for each Kitchen Joker owned.'
            },
            ['unlock'] = {
                [1] = ''
            }
        },
        pos = {
            x = 3,
            y = 0
        },
        display_size = {
            w = 71 * 1, 
            h = 95 * 1
        },
        cost = 20,
        rarity = 4,
        blueprint_compat = true,
        eternal_compat = true,
        perishable_compat = true,
        unlocked = true,
        discovered = false,
        atlas = 'CustomJokers',
        in_pool = function(self, args)
            return (
                not args 
                or args.source ~= 'sho' 
                or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
            )
            and true
        end,
        
        calculate = function(self, card, context)
            if context.cardarea == G.jokers and context.joker_main  then
                return {
                    Xmult = card.ability.extra.Xmult
                }
                return {
                    Xmult = card.ability.extra.Xmult2
                }
                return {
                    Xmult = card.ability.extra.Xmult3
                }
                return {
                    Xmult = card.ability.extra.Xmult4
                }
                return {
                    Xmult = card.ability.extra.Xmult5
                }
                return {
                    Xmult = card.ability.extra.Xmult6
                }
                return {
                    Xmult = card.ability.extra.Xmult7
                }
                return {
                    Xmult = card.ability.extra.Xmult8
                }
                return {
                    Xmult = card.ability.extra.Xmult9
                }
                return {
                    Xmult = card.ability.extra.Xmult10
                }
                return {
                    Xmult = card.ability.extra.Xmult11
                }
                return {
                    Xmult = card.ability.extra.Xmult12
                }
                return {
                    Xmult = card.ability.extra.Xmult13
                }
                return {
                    Xmult = card.ability.extra.Xmult14
                }
            end
        end
    }