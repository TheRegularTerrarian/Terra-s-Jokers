SMODS.Joker{ --Oven Leader
    key = "ovenleader",
    config = {
        extra = {
            Xmult = 2,
            Xmult2 = 2,
            Xmult3 = 2,
            Xmult4 = 2,
            Xmult5 = 2,
            Xmult6 = 2,
            Xmult7 = 2,
            Xmult8 = 2,
            Xmult9 = 2,
            Xmult10 = 2,
            Xmult11 = 2,
            Xmult12 = 2,
            Xmult13 = 2,
            Xmult14 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Oven Leader',
        ['text'] = {
            [1] = 'Gain {X:red,C:white}X2{} Mult for each Kitchen Joker owned.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 3,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    in_pool = function(self, args)
          return (
          not args 
          or args.source ~= 'sho' 
          or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
          )
          and true
      end,

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
                for i = 1, #G.jokers.cards do
                    if G.jokers.cards[i].config.center.key == "j_skewer" then
                        return true
                        end
                    end
                    return false
                    end)() then
                        return {
                            Xmult = card.ability.extra.Xmult
                        }
                    elseif (function()
                        for i = 1, #G.jokers.cards do
                            if G.jokers.cards[i].config.center.key == "j_terrasjo_fridge, j_terrasjo_fridgefreezer" then
                                return true
                                end
                            end
                            return false
                            end)() then
                                return {
                                    Xmult = card.ability.extra.Xmult2
                                }
                            elseif (function()
                                for i = 1, #G.jokers.cards do
                                    if G.jokers.cards[i].config.center.key == "j_terrasjo_knifeblock" then
                                        return true
                                        end
                                    end
                                    return false
                                    end)() then
                                        return {
                                            Xmult = card.ability.extra.Xmult3
                                        }
                                    elseif (function()
                                        for i = 1, #G.jokers.cards do
                                            if G.jokers.cards[i].config.center.key == "j_terrasjo_rollingpin" then
                                                return true
                                                end
                                            end
                                            return false
                                            end)() then
                                                return {
                                                    Xmult = card.ability.extra.Xmult4
                                                }
                                            elseif (function()
                                                for i = 1, #G.jokers.cards do
                                                    if G.jokers.cards[i].config.center.key == "j_terrasjo_coldstorage" then
                                                        return true
                                                        end
                                                    end
                                                    return false
                                                    end)() then
                                                        return {
                                                            Xmult = card.ability.extra.Xmult5
                                                        }
                                                    elseif (function()
                                                        for i = 1, #G.jokers.cards do
                                                            if G.jokers.cards[i].config.center.key == "j_terrasjo_microwave" then
                                                                return true
                                                                end
                                                            end
                                                            return false
                                                            end)() then
                                                                return {
                                                                    Xmult = card.ability.extra.Xmult6
                                                                }
                                                            elseif (function()
                                                                for i = 1, #G.jokers.cards do
                                                                    if G.jokers.cards[i].config.center.key == "j_terrasjo_waiter" then
                                                                        return true
                                                                        end
                                                                    end
                                                                    return false
                                                                    end)() then
                                                                        return {
                                                                            Xmult = card.ability.extra.Xmult7
                                                                        }
                                                                    elseif (function()
                                                                        for i = 1, #G.jokers.cards do
                                                                        if G.jokers.cards[i].config.center.key == "j_terrasjo_blender" then
                                                                            return true
                                                                            end
                                                                        end
                                                                        return false
                                                                        end)() then
                                                                            return {
                                                                                Xmult = card.ability.extra.Xmult8
                                                                            }
                                                                        elseif (function()
                                                                            for i = 1, #G.jokers.cards do
                                                                                if G.jokers.cards[i].config.center.key == "j_terrasjo_toaster" then
                                                                                    return true
                                                                                    end
                                                                                end
                                                                                return false
                                                                                end)() then
                                                                                    return {
                                                                                        Xmult = card.ability.extra.Xmult9
                                                                                    }
                                                                                elseif (function()
                                                                                    for i = 1, #G.jokers.cards do
                                                                                        if G.jokers.cards[i].config.center.key == "j_terrasjo_garlicbread" then
                                                                                            return true
                                                                                            end
                                                                                        end
                                                                                        return false
                                                                                        end)() then
                                                                                            return {
                                                                                                Xmult = card.ability.extra.Xmult10
                                                                                            }
                                                                                        elseif (function()
                                                                                            for i = 1, #G.jokers.cards do
                                                                                                if G.jokers.cards[i].config.center.key == "j_terrasjo_chef" then
                                                                                                    return true
                                                                                                    end
                                                                                                end
                                                                                                return false
                                                                                                end)() then
                                                                                                    return {
                                                                                                        Xmult = card.ability.extra.Xmult11
                                                                                                    }
                                                                                                elseif (function()
                                                                                                    for i = 1, #G.jokers.cards do
                                                                                                        if G.jokers.cards[i].config.center.key == "j_terrasjo_airfryer" then
                                                                                                            return true
                                                                                                            end
                                                                                                        end
                                                                                                        return false
                                                                                                        end)() then
                                                                                                            return {
                                                                                                                Xmult = card.ability.extra.Xmult12
                                                                                                            }
                                                                                                        elseif (function()
                                                                                                            for i = 1, #G.jokers.cards do
                                                                                                                if G.jokers.cards[i].config.center.key == "j_terrasjo_sink" then
                                                                                                                    return true
                                                                                                                    end
                                                                                                                end
                                                                                                                return false
                                                                                                                end)() then
                                                                                                                    return {
                                                                                                                        Xmult = card.ability.extra.Xmult13
                                                                                                                    }
                                                                                                                elseif (function()
                                                                                                                    for i = 1, #G.jokers.cards do
                                                                                                                        if G.jokers.cards[i].config.center.key == "j_terrasjo_kettle" then
                                                                                                                            return true
                                                                                                                            end
                                                                                                                        end
                                                                                                                        return false
                                                                                                                        end)() then
                                                                                                                            return {
                                                                                                                                Xmult = card.ability.extra.Xmult14
                                                                                                                            }
                                                                                                                        end
                                                                                                                    end
                                                                                                                end
}