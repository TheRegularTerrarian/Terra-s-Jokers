
SMODS.Joker{ --Oven Leader
    key = "ovenleader",
    config = {
        extra = {
            Xmult = 2
        }
    },
    loc_txt = {
        ['name'] = 'Oven Leader',
        ['text'] = {
            [1] = 'Kitchen Jokers give {X:red,C:white}X2{} Mult.',
            [2] = 'Gains {X:red,C:white}X2{} Mult if you own a Kitchen Joker.'
            },
            ['unlock'] = {
                [1] = ''
            }
        },
        pos = {
            x = 3,
            y = 0
        },
        display_size = {
            w = 71 * 1, 
            h = 95 * 1
        },
        cost = 20,
        rarity = 4,
        blueprint_compat = true,
        eternal_compat = true,
        perishable_compat = true,
        unlocked = true,
        discovered = false,
        atlas = 'CustomJokers',
        in_pool = function(self, args)
            return (
                not args 
                or args.source ~= 'sho' 
                or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
            )
            and true
        end,
        
        calculate = function(self, card, context)
            if context.cardarea == G.jokers and context.joker_main  then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            end
        end
    }