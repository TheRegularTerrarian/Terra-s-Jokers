SMODS.Joker{ --Security
    key = "security",
    config = {
        extra = {
            Xmult = 3,
            var1 = 0,
            no = 0
        }
    },
    loc_txt = {
        ['name'] = 'Security',
        ['text'] = {
            [1] = 'When a {C:attention}Blind{} is selected, if you have',
            [2] = '5 or more {C:attention}Jokers{}, a random',
            [3] = '{C:attention}Joker{} is destroyed. When playing a hand,',
            [4] = 'if you have 4 or less {C:attention}Jokers{}, gain {X:red,C:white}X3{} Mult.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 2,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.setting_blind  then
            if #G.jokers.cards >= 5 then
                return {
                    func = function()
                        local destructable_jokers = {}
                        for i, joker in ipairs(G.jokers.cards) do
                            if joker ~= card and not SMODS.is_eternal(joker) and not joker.getting_sliced then
                                table.insert(destructable_jokers, joker)
                            end
                        end
                        local target_joker = #destructable_jokers > 0 and pseudorandom_element(destructable_jokers, pseudoseed('destroy_joker')) or nil
                        
                        if target_joker then
                            local joker_sell_value = target_joker.sell_cost or 0
                            local sell_value_gain = joker_sell_value * 2
                            card.ability.extra.var1 = card.ability.extra.var1 + sell_value_gain
                            target_joker.getting_sliced = true
                            G.E_MANAGER:add_event(Event({
                            func = function()
                                target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                                return true
                                end
                            }))
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                        end
                        return true
                        end
                    }
                end
            end
            if context.cardarea == G.jokers and context.joker_main  then
                if #G.jokers.cards <= 4 then
                    return {
                        Xmult = card.ability.extra.Xmult
                    }
                end
            end
        end
}