
SMODS.Joker{ --Gunsmith
    key = "gunsmith",
    config = {
        extra = {
            addingmult = 0,
            odds = 6,
            n = 0
        }
    },
    loc_txt = {
        ['name'] = 'Gunsmith',
        ['text'] = {
            [1] = 'Played {C:attention}Aces{} have a {C:green}1 in 6{} chance to be destroyed.',
            [2] = 'When a card is destroyed, gain {C:red}+6{} Mult.',
            [3] = '{C:inactive}(Currently{} {C:red}+#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 9,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = false,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_terrasjo_gunsmith') 
        return {vars = {card.ability.extra.addingmult, new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.destroy_card and context.destroy_card.should_destroy  then
            return { remove = true }
        end
        if context.individual and context.cardarea == G.play  then
            context.other_card.should_destroy = false
            if context.other_card:get_id() == 14 then
                if SMODS.pseudorandom_probability(card, 'group_0_bf165a70', 1, card.ability.extra.odds, 'j_terrasjo_gunsmith', false) then
                    context.other_card.should_destroy = true
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                end
            end
        end
        if context.remove_playing_cards  then
            return {
                func = function()
                    card.ability.extra.addingmult = (card.ability.extra.addingmult) + 6
                    return true
                end,
                message = "Shot!"
            }
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                mult = card.ability.extra.addingmult
            }
        end
    end
}