SMODS.Joker{ --Guide
    key = "guide",
    config = {
        extra = {
            commonjokers = 0
        }
    },
    loc_txt = {
        ['name'] = 'Guide',
        ['text'] = {
            [1] = 'Gains {C:blue}+50{} Chips per {C:common}Common{} Joker owned.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 4,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
            chips = ((function() local count = 0; for _, joker in ipairs(G.jokers and G.jokers.cards or {}) do if joker.config.center.rarity == 1 then count = count + 1 end end; return count end)()) * 50
            }
        end
    end
}