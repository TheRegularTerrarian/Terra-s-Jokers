
SMODS.Joker{ --Empress Of Light
    key = "empressoflight",
    config = {
        extra = {
            slot_change = 1
        }
    },
    loc_txt = {
        ['name'] = 'Empress Of Light',
        ['text'] = {
            [1] = '{C:attention}Enhances{} all played cards to {C:attention}Polychrome{}',
            [2] = 'and {C:attention}Glass{}. While you have this {C:attention}Joker{},',
                [3] = '{C:attention}-1 Joker{} slots and you may not hold',
                [4] = 'any {C:attention}Consumables{}.'
            },
            ['unlock'] = {
                [1] = ''
            }
        },
        pos = {
            x = 5,
            y = 4
        },
        display_size = {
            w = 71 * 1, 
            h = 95 * 1
        },
        cost = 10,
        rarity = 3,
        blueprint_compat = true,
        eternal_compat = true,
        perishable_compat = true,
        unlocked = true,
        discovered = false,
        atlas = 'CustomJokers',
        pools = { ["terrasjo_terras_jokers"] = true },
        
        calculate = function(self, card, context)
            if context.individual and context.cardarea == G.play  then
                context.other_card:set_ability(G.P_CENTERS.m_glass)
                context.other_card:set_edition("e_polychrome", true)
                return {
                    message = "Blessed!"
                }
            end
        end,
        
        add_to_deck = function(self, card, from_debuff)
            original_slots = G.consumeables.config.card_limit
            G.E_MANAGER:add_event(Event({func = function()
                G.consumeables.config.card_limit = card.ability.extra.slot_change
                return true
            end }))
            G.jokers.config.card_limit = math.max(1, G.jokers.config.card_limit - 1)
        end,
        
        remove_from_deck = function(self, card, from_debuff)
            if original_slots then
                G.E_MANAGER:add_event(Event({func = function()
                    G.consumeables.config.card_limit = original_slots
                    return true
                end }))
            end
            G.jokers.config.card_limit = G.jokers.config.card_limit + 1
        end
    }