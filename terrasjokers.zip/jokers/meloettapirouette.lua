
SMODS.Joker{ --Meloetta (Pirouette)
    key = "meloettapirouette",
    config = {
        extra = {
            repetitions0 = 1,
            chips0 = 130
        }
    },
    loc_txt = {
        ['name'] = 'Meloetta (Pirouette)',
        ['text'] = {
            [1] = 'When a card is scored, {C:attention}retrigger{}',
            [2] = 'it and gain {C:blue}+130{} Chips.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 2,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' 
            or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
            return {
                repetitions = 1,
                message = localize('k_again_ex'),
                extra = {
                    chips = 130,
                    colour = G.C.CHIPS
                }
            }
        end
    end
}