SMODS.Joker{ --Meloetta (Pirouette)
    key = "meloettapirouette",
    config = {
        extra = {
            repetitions = 1,
            chips = 648
        }
    },
    loc_txt = {
        ['name'] = 'Meloetta (Pirouette)',
        ['text'] = {
            [1] = 'When a card is scored, {C:attention}retrigger{} it. Gives {C:blue}+648{} Chips'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 2,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    in_pool = function(self, args)
          return (
          not args 
          or args.source ~= 'sho' 
          or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
          )
          and true
      end,

    
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
            return {
                repetitions = card.ability.extra.repetitions,
                message = localize('k_again_ex')
            }
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                chips = card.ability.extra.chips
            }
        end
    end
}