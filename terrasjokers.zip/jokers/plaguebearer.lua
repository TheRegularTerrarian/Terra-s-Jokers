SMODS.Joker{ --Plaguebearer
    key = "plaguebearer",
    config = {
        extra = {
            start_dissolve = 0,
            y = 0,
            no = 0,
            var1 = 0,
            ignore = 0
        }
    },
    loc_txt = {
        ['name'] = 'Plaguebearer',
        ['text'] = {
            [1] = 'When a {C:attention}Blind{} is selected, if you have {C:attention}40{}',
            [2] = '{C:spades}Spades{} or {C:clubs}Clubs{} in your deck, {C:attention}destroy{}',
            [3] = 'self and create {C:red}Pestilence{}.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terrasjo_jokers"] = true, ["terrasjo_terras_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.setting_blind  then
            if (function()
                local count = 0
                for _, playing_card in pairs(G.playing_cards or {}) do
                    if (playing_card:is_suit("Spades") or playing_card:is_suit("Clubs")) then
                        count = count + 1
                    end
                end
                return count >= 40
                end)() then
                    return {
                        func = function()
                            local destructable_jokers = {}
                            for i, joker in ipairs(G.jokers.cards) do
                                if joker ~= card and not SMODS.is_eternal(joker) and not joker.getting_sliced then
                                    table.insert(destructable_jokers, joker)
                                end
                            end
                            local target_joker = #destructable_jokers > 0 and pseudorandom_element(destructable_jokers, pseudoseed('destroy_joker')) or nil
                            
                            if target_joker then
                                target_joker.getting_sliced = true
                                G.E_MANAGER:add_event(Event({
                                func = function()
                                    target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                                    return true
                                    end
                                }))
                                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Transformed!", colour = G.C.RED})
                            end
                            return true
                            end,
                            extra = {
                            func = function()
                                
                                local created_joker = true
                                G.E_MANAGER:add_event(Event({
                                func = function()
                                    local joker_card = SMODS.add_card({ set = 'Joker', key = 'j_terrasjo_pestilence' })
                                    if joker_card then
                                        joker_card:set_edition("e_negative", true)
                                        
                                    end
                                    
                                    return true
                                    end
                                }))
                                
                                if created_joker then
                                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_joker'), colour = G.C.BLUE})
                                end
                                return true
                                end,
                                colour = G.C.BLUE
                            }
                        }
                    end
                end
            end
}