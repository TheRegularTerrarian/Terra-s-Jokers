
SMODS.Joker{ --Poisoner
    key = "poisoner",
    config = {
        extra = {
            chipsvar = 10,
            multvar = 2
        }
    },
    loc_txt = {
        ['name'] = 'Poisoner',
        ['text'] = {
        [1] = 'Gives {C:blue}+10{} Chips and {C:red}+2{} Mult. At the end of every',
        [2] = 'round, permanently give {C:blue}+10{} Chips and {C:red}+2{} Mult.',
        [3] = '{C:inactive}(Currently{} {C:blue}+#1#{} {C:inactive}Chips){} {C:inactive}(Currently{} {C:red}+#2#{} {C:inactive}Mult){}'
    },
    ['unlock'] = {
        [1] = 'Unlocked by default.'
    }
},
pos = {
    x = 5,
    y = 5
},
display_size = {
    w = 71 * 1, 
    h = 95 * 1
},
cost = 4,
rarity = 1,
blueprint_compat = true,
eternal_compat = true,
perishable_compat = true,
unlocked = true,
discovered = false,
atlas = 'CustomJokers',
pools = { ["terrasjo_terrasjo_jokers"] = true, ["terrasjo_Coven_Jokers"] = true, ["terrasjo_terras_jokers"] = true },

loc_vars = function(self, info_queue, card)
    
    return {vars = {card.ability.extra.chipsvar, card.ability.extra.multvar}}
end,

calculate = function(self, card, context)
    if context.cardarea == G.jokers and context.joker_main  then
        return {
            chips = card.ability.extra.chipsvar,
            extra = {
                mult = card.ability.extra.multvar
            }
        }
    end
    if context.end_of_round and context.game_over == false and context.main_eval  then
        return {
            func = function()
                card.ability.extra.chipsvar = (card.ability.extra.chipsvar) + 10
                return true
            end,
            extra = {
                func = function()
                    card.ability.extra.multvar = (card.ability.extra.multvar) + 2
                    return true
                end,
                colour = G.C.GREEN
            }
        }
    end
end
}