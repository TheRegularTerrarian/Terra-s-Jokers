SMODS.Joker{ --Frauder
    key = "frauder",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Frauder',
        ['text'] = {
            [1] = 'When a {C:attention}Blind{} is selected, add a random card',
            [2] = 'to your deck. If you have {C:gold}$50{} or more, high',
            [3] = 'quality cards are created.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 1,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.setting_blind  then
            if G.GAME.dollars >= to_big(50) then
                local card_front = pseudorandom_element(G.P_CARDS, pseudoseed('add_card_hand'))
                local new_card = create_playing_card({
                front = card_front,
                center = 
                pseudorandom_element({G.P_CENTERS.m_gold, G.P_CENTERS.m_steel, G.P_CENTERS.m_glass, G.P_CENTERS.m_wild, G.P_CENTERS.m_mult, G.P_CENTERS.m_lucky, G.P_CENTERS.m_stone}, pseudoseed('add_card_enhancement'))
            }, G.discard, true, false, nil, true)
            new_card:set_seal(pseudorandom_element({'Gold','Red','Blue','Purple'}, pseudoseed('add_card_seal')), true)
            new_card:set_edition(pseudorandom_element({'e_foil','e_holo','e_polychrome','e_negative'}, pseudoseed('add_card_edition')), true)
            
            G.E_MANAGER:add_event(Event({
            func = function()
                new_card:start_materialize()
                G.play:emplace(new_card)
                return true
                end
            }))
            return {
                func = function()
                    G.E_MANAGER:add_event(Event({
                    func = function()
                        G.deck.config.card_limit = G.deck.config.card_limit + 1
                        return true
                        end
                    }))
                    draw_card(G.play, G.deck, 90, 'up')
                        SMODS.calculate_context({ playing_card_added = true, cards = { new_card } })
                    end,
                    message = "Laundered!"
                }
            elseif G.GAME.dollars <= to_big(49) then
                local card_front = pseudorandom_element(G.P_CARDS, pseudoseed('add_card_hand'))
                local new_card = create_playing_card({
                front = card_front,
                center = 
                G.P_CENTERS.c_base
            }, G.discard, true, false, nil, true)
            
            G.E_MANAGER:add_event(Event({
            func = function()
                new_card:start_materialize()
                G.play:emplace(new_card)
                return true
                end
            }))
            return {
                func = function()
                    G.E_MANAGER:add_event(Event({
                    func = function()
                        G.deck.config.card_limit = G.deck.config.card_limit + 1
                        return true
                        end
                    }))
                    draw_card(G.play, G.deck, 90, 'up')
                        SMODS.calculate_context({ playing_card_added = true, cards = { new_card } })
                    end,
                    message = "Laundered!"
                }
            end
        end
    end
}