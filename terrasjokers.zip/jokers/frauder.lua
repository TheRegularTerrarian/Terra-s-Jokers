SMODS.Joker{ --Frauder
    key = "frauder",
    config = {
        extra = {
            deck = 0
        }
    },
    loc_txt = {
        ['name'] = 'Frauder',
        ['text'] = {
            [1] = 'When a {C:attention}Blind{} is selected, add a random card',
            [2] = 'to your deck. If you have {C:gold}$50{} or more, cards with',
            [3] = 'a random {C:attention}Enhancement{}, {C:attention}Seal{} and {C:attention}Edition{} are created.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 1,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.setting_blind  then
            if G.GAME.dollars >= to_big(50) then
            elseif G.GAME.dollars <= to_big(49) then
            end
        end
    end
}