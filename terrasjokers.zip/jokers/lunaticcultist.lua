SMODS.Joker{ --Lunatic Cultist
    key = "lunaticcultist",
    config = {
        extra = {
            dollars = 2,
            dollars2 = 2,
            dollars3 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Lunatic Cultist',
        ['text'] = {
            [1] = 'If the {C:attention}first hand{} of round contains {C:attention}4{} cards,',
            [2] = 'enhance them to {C:attention}Holographic{}. Otherwise, if played',
            [3] = 'hand contains 1 card, enhance it to Holographic.',
            [4] = '{C:attention}Consumables{} cost {C:gold}$3{} to use. {C:green}Rerolls{} and cards in',
            [5] = 'the shop cost {C:gold}$2{} extra.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 0,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 10,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if G.GAME.current_round.hands_played == 0 then
            else
            end
        end
        if context.using_consumeable  then
            return {
                dollars = -card.ability.extra.dollars
            }
        end
        if context.reroll_shop  then
            return {
                dollars = -card.ability.extra.dollars2
            }
        end
        if context.buying_card  then
            return {
                dollars = -card.ability.extra.dollars3
            }
        end
    end
}