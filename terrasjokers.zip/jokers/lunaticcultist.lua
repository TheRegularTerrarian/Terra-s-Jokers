
SMODS.Joker{ --Lunatic Cultist
    key = "lunaticcultist",
    config = {
        extra = {
            dollars0 = 2,
            dollars = 2,
            dollars2 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Lunatic Cultist',
        ['text'] = {
            [1] = 'If the {C:attention}first hand{} of round contains {C:attention}4{} cards,',
            [2] = 'enhance them to {C:attention}Holographic{}. Otherwise, if played',
            [3] = 'hand contains 1 card, enhance it to Holographic.',
            [4] = '{C:attention}Consumables{} cost {C:gold}$3{} to use. {C:green}Rerolls{} and cards in',
            [5] = 'the shop cost {C:gold}$2{} extra.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 9,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 10,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (G.GAME.current_round.hands_played == 0 and to_big(#context.full_hand) == to_big(4)) then
                local scored_card = context.other_card
                G.E_MANAGER:add_event(Event({
                    func = function()
                        
                        scored_card:set_edition("e_holo", true)
                        card_eval_status_text(scored_card, 'extra', nil, nil, nil, {message = "Indocrinated!", colour = G.C.ORANGE})
                        return true
                    end
                }))
            elseif to_big(#context.scoring_hand) == to_big(1) then
                local scored_card = context.other_card
                G.E_MANAGER:add_event(Event({
                    func = function()
                        
                        scored_card:set_edition("e_holo", true)
                        card_eval_status_text(scored_card, 'extra', nil, nil, nil, {message = "Indocrinated!", colour = G.C.ORANGE})
                        return true
                    end
                }))
            end
        end
        if context.using_consumeable  then
            return {
                
                func = function()
                    
                    local current_dollars = G.GAME.dollars
                    local target_dollars = G.GAME.dollars - 2
                    local dollar_value = target_dollars - current_dollars
                    ease_dollars(dollar_value)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(2), colour = G.C.MONEY})
                    return true
                end
            }
        end
        if context.reroll_shop  then
            return {
                
                func = function()
                    
                    local current_dollars = G.GAME.dollars
                    local target_dollars = G.GAME.dollars - 2
                    local dollar_value = target_dollars - current_dollars
                    ease_dollars(dollar_value)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(2), colour = G.C.MONEY})
                    return true
                end
            }
        end
        if context.buying_card  then
            return {
                
                func = function()
                    
                    local current_dollars = G.GAME.dollars
                    local target_dollars = G.GAME.dollars - 2
                    local dollar_value = target_dollars - current_dollars
                    ease_dollars(dollar_value)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(2), colour = G.C.MONEY})
                    return true
                end
            }
        end
    end
}