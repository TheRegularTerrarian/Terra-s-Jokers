
SMODS.Joker{ --Dryad
    key = "dryad",
    config = {
        extra = {
            odds = 3,
            chips0 = 80
        }
    },
    loc_txt = {
        ['name'] = 'Dryad',
        ['text'] = {
            [1] = 'Scored cards have a {C:green}1 in 3{}',
            [2] = 'chance to give {C:blue}+80{} Chips.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 9,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_terrasjo_dryad') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_608cf2d4', 1, card.ability.extra.odds, 'j_terrasjo_dryad', false) then
                    SMODS.calculate_effect({chips = 80}, card)
                end
            end
        end
    end
}