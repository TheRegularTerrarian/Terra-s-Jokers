
SMODS.Joker{ --Necromancer
    key = "necromancer",
    config = {
        extra = {
            Coven_Jokers = 0,
            eternal = 0,
            ignore = 0
        }
    },
    loc_txt = {
        ['name'] = 'Necromancer',
        ['text'] = {
            [1] = 'When a {C:tarot}Coven{} {C:attention}Joker{} is {C:attention}destroyed{} or sold, create',
            [2] = 'a random Eternal {C:negative}Negative{} {C:tarot}Coven{} {C:attention}Joker{}.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terrasjo_jokers"] = true, ["terrasjo_Coven_Jokers"] = true, ["terrasjo_terras_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.selling_card  then
            if to_big(#G.jokers.highlighted) == to_big(1) then
                return {
                    func = function()
                        
                        local created_joker = false
                        if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                            created_joker = true
                            G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    local joker_card = SMODS.add_card({ set = 'terrasjo_Coven_Jokers' })
                                    if joker_card then
                                        joker_card:set_edition("negative", true)
                                        joker_card:add_sticker('eternal', true)
                                    end
                                    G.GAME.joker_buffer = 0
                                    return true
                                end
                            }))
                        end
                        if created_joker then
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_joker'), colour = G.C.BLUE})
                        end
                        return true
                    end
                }
            end
        end
    end
}