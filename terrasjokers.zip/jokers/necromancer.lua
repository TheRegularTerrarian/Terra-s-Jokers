SMODS.Joker{ --Necromancer
    key = "necromancer",
    config = {
        extra = {
            Coven_Jokers = 0,
            ignore = 0,
            shatter = 0,
            n = 0
        }
    },
    loc_txt = {
        ['name'] = 'Necromancer',
        ['text'] = {
            [1] = 'When a {C:tarot}Coven{} {C:attention}Joker{} is {C:attention}destroyed{} or sold, create',
            [2] = 'a random {C:negative}Negative{} {C:tarot}Coven{} {C:attention}Joker{} and {C:attention}destroy{} self.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terrasjo_jokers"] = true, ["terrasjo_Coven_Jokers"] = true, ["terrasjo_terras_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.selling_card  then
            return {
                func = function()
                    
                    local created_joker = true
                    G.E_MANAGER:add_event(Event({
                    func = function()
                        local joker_card = SMODS.add_card({ set = 'terrasjo_Coven_Jokers' })
                        if joker_card then
                            joker_card:set_edition("e_negative", true)
                            
                        end
                        
                        return true
                        end
                    }))
                    
                    if created_joker then
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_joker'), colour = G.C.BLUE})
                    end
                    return true
                    end,
                    extra = {
                    func = function()
                        card:shatter()
                        return true
                        end,
                        colour = G.C.RED
                    }
                }
            end
        end
}