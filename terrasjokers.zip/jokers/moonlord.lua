
SMODS.Joker{ --Moon Lord
    key = "moonlord",
    config = {
        extra = {
            slot_change = '1',
            reduction_value = '1',
            hands_change = '10',
            discards_change = '10',
            hand_size_increase = '5',
            levels0 = 2,
            levels = 2
        }
    },
    loc_txt = {
        ['name'] = 'Moon Lord',
        ['text'] = {
            [1] = 'There can be only one. Increases {C:blue}Hands{},',
            [2] = '{C:red}Discards{} and {C:attention}Hand Size{} significantly.',
            [3] = 'Adds {C:attention}1 Consumable Slot{}. Levels up played and discarded',
            [4] = '{C:attention}poker hand{}. Destroys other {C:attention}Jokers{}.',
            [5] = 'Applies {C:attention}Shortcut{} and {C:attention}Four Fingers{}. Eternal.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 0,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' 
            or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    set_ability = function(self, card, initial)
        card:set_eternal(true)
    end,
    
    calculate = function(self, card, context)
        if context.setting_blind  then
            return {
                func = function()
                    local my_pos = nil
                    for i = 1, #G.jokers.cards do
                        if G.jokers.cards[i] == card then
                            my_pos = i
                            break
                        end
                    end
                    local target_joker = nil
                    if my_pos and my_pos > 1 then
                        local joker = G.jokers.cards[my_pos - 1]
                        if true and not joker.getting_sliced then
                            target_joker = joker
                        end
                    end
                    
                    if target_joker then
                        if target_joker.ability.eternal then
                            target_joker.ability.eternal = nil
                        end
                        target_joker.getting_sliced = true
                        G.E_MANAGER:add_event(Event({
                            func = function()
                                target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                                return true
                            end
                        }))
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                    end
                    return true
                end,
                extra = {
                    func = function()
                        local my_pos = nil
                        for i = 1, #G.jokers.cards do
                            if G.jokers.cards[i] == card then
                                my_pos = i
                                break
                            end
                        end
                        local target_joker = nil
                        if my_pos and my_pos < #G.jokers.cards then
                            local joker = G.jokers.cards[my_pos + 1]
                            if true and not joker.getting_sliced then
                                target_joker = joker
                            end
                        end
                        
                        if target_joker then
                            if target_joker.ability.eternal then
                                target_joker.ability.eternal = nil
                            end
                            target_joker.getting_sliced = true
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                                    return true
                                end
                            }))
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                        end
                        return true
                    end,
                    colour = G.C.RED
                }
            }
        end
        if context.cardarea == G.jokers and context.joker_main  then
            local target_hand = (context.scoring_name or "High Card")
            level_up_hand(card, target_hand, true, 2)
            return {
                message = localize('k_level_up_ex')
            }
        end
        if context.pre_discard  then
            local text, poker_hands, text_disp, loc_disp_text = G.FUNCS.get_poker_hand_info(G.hand.highlighted)
            local target_hand2 = text
            
            level_up_hand(card, target_hand2, true, 2)
            return {
                message = localize('k_level_up_ex')
            }
        end
    end,
    
    add_to_deck = function(self, card, from_debuff)
        card.ability.extra.original_joker_slots = G.jokers.config.card_limit
        G.jokers.config.card_limit = 1
        G.E_MANAGER:add_event(Event({func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit + 1
            return true
        end }))
        -- Flush/Straight requirements reduced by 1
        -- Shortcut straights enabled
        card.ability.extra.original_hands = G.GAME.round_resets.hands
        G.GAME.round_resets.hands = 10
        card.ability.extra.original_discards = G.GAME.round_resets.discards
        G.GAME.round_resets.discards = 10
        G.hand:change_size(5)
    end,
    
    remove_from_deck = function(self, card, from_debuff)
        if card.ability.extra.original_joker_slots then
            G.jokers.config.card_limit = card.ability.extra.original_joker_slots
        end
        G.E_MANAGER:add_event(Event({func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit - 1
            return true
        end }))
        -- Flush/Straight requirements restored
        -- Shortcut straights disabled
        if card.ability.extra.original_hands then
            G.GAME.round_resets.hands = card.ability.extra.original_hands
        end
        if card.ability.extra.original_discards then
            G.GAME.round_resets.discards = card.ability.extra.original_discards
        end
        G.hand:change_size(-5)
    end
}


local smods_four_fingers_ref = SMODS.four_fingers
function SMODS.four_fingers()
    if next(SMODS.find_card("j_terrasjo_moonlord")) then
        return 4
    end
    return smods_four_fingers_ref()
end
local smods_shortcut_ref = SMODS.shortcut
function SMODS.shortcut()
    if next(SMODS.find_card("j_terrasjo_moonlord")) then
        return true
    end
    return smods_shortcut_ref()
end