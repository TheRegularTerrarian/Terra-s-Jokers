SMODS.Joker{ --Microwave
    key = "microwave",
    config = {
        extra = {
            xmultvar = 1,
            Xmult = 2
        }
    },
    loc_txt = {
        ['name'] = 'Microwave',
        ['text'] = {
            [1] = 'Permanently gain {X:red,C:white}X0.1{} Mult for each {C:attention}Enhanced{} card played.',
            [2] = 'Loses {X:red,C:white}X0.1{} Mult for each non-{C:attention}Enhanced{} card played.',
            [3] = '{C:inactive}(Currently{} {X:red,C:white}X#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 0,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = false,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },

    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.xmultvar}}
    end,

    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (function()
                local enhancements = SMODS.get_enhancements(context.other_card)
                for k, v in pairs(enhancements) do
                    if v then
                        return true
                        end
                    end
                    return false
                    end)() then
                        card.ability.extra.xmultvar = (card.ability.extra.xmultvar) + 0.1
                    elseif not ((function()
                        local enhancements = SMODS.get_enhancements(context.other_card)
                        for k, v in pairs(enhancements) do
                            if v then
                                return true
                                end
                            end
                            return false
                            end)()) then
                                card.ability.extra.xmultvar = math.max(0, (card.ability.extra.xmultvar) - 0.1)
                            end
                        end
                        if context.cardarea == G.jokers and context.joker_main  then
                            if (function()
                                for i = 1, #G.jokers.cards do
                                    if G.jokers.cards[i].config.center.key == "j_terrasjo_ovenleader" then
                                        return true
                                        end
                                    end
                                    return false
                                    end)() then
                                        return {
                                            Xmult = card.ability.extra.Xmult
                                        }
                                    else
                                        return {
                                            Xmult = card.ability.extra.xmultvar
                                        }
                                    end
                                end
                            end
}