
SMODS.Joker{ --Microwave
    key = "microwave",
    config = {
        extra = {
            var1 = 1,
            notgamebreaking = 0
        }
    },
    loc_txt = {
        ['name'] = 'Microwave',
        ['text'] = {
            [1] = 'Permanently gain {X:red,C:white}X0.1{} Mult for each {C:attention}Enhanced{} card played.',
                [2] = 'Loses {X:red,C:white}X0.1{} Mult for each non-{C:attention}Enhanced{} card played.',
                    [3] = '{C:inactive}(Currently{} {X:red,C:white}X#1#{} {C:inactive}Mult){}'
                },
                ['unlock'] = {
                    [1] = ''
                }
            },
            pos = {
                x = 0,
                y = 1
            },
            display_size = {
                w = 71 * 1, 
                h = 95 * 1
            },
            cost = 8,
            rarity = 2,
            blueprint_compat = true,
            eternal_compat = true,
            perishable_compat = false,
            unlocked = true,
            discovered = false,
            atlas = 'CustomJokers',
            pools = { ["terrasjo_terras_jokers"] = true },
            
            loc_vars = function(self, info_queue, card)
                
                return {vars = {card.ability.extra.var1, card.ability.extra.notgamebreaking}}
            end,
            
            calculate = function(self, card, context)
                if context.individual and context.cardarea == G.play  then
                    if (function()
                        local enhancements = SMODS.get_enhancements(context.other_card)
                        for k, v in pairs(enhancements) do
                            if v then
                                return true
                            end
                        end
                        return false
                    end)() then
                        card.ability.extra.var1 = (card.ability.extra.var1) + 0.1
                        elseif not ((function()
                            local enhancements = SMODS.get_enhancements(context.other_card)
                            for k, v in pairs(enhancements) do
                                if v then
                                    return true
                                end
                            end
                            return false
                        end)()) then
                            card.ability.extra.var1 = math.max(0, (card.ability.extra.var1) - 0.1)
                            elseif to_big((card.ability.extra.notgamebreaking or 0)) < to_big(1) then
                                card.ability.extra.var1 = (card.ability.extra.var1) + 2
                                card.ability.extra.notgamebreaking = (card.ability.extra.notgamebreaking) + 1
                            end
                        end
                        if context.cardarea == G.jokers and context.joker_main  then
                            return {
                                Xmult = card.ability.extra.var1
                            }
                        end
                    end
                }