
SMODS.Joker{ --Merchant
    key = "merchant",
    config = {
        extra = {
            mult = 20,
            dollars = 5
        }
    },
    loc_txt = {
        ['name'] = 'Merchant',
        ['text'] = {
            [1] = 'Lose {C:gold}$5{} every round. Gain {C:red}+20{} Mult',
            [2] = 'when a hand is played.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 4,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                mult = card.ability.extra.mult
            }
        end
        if context.setting_blind  then
            return {
                
                func = function()
                    
                    local current_dollars = G.GAME.dollars
                    local target_dollars = G.GAME.dollars - card.ability.extra.dollars
                    local dollar_value = target_dollars - current_dollars
                    ease_dollars(dollar_value)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(card.ability.extra.dollars), colour = G.C.MONEY})
                    return true
                end
            }
        end
    end
}