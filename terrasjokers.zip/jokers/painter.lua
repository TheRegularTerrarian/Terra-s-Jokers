
SMODS.Joker{ --Painter
    key = "painter",
    config = {
        extra = {
            hand_size0 = 2,
            hand_size = 2
        }
    },
    loc_txt = {
        ['name'] = 'Painter',
        ['text'] = {
            [1] = 'When {C:attention}Blind{} is selected, if you have {C:attention}10{} or',
            [2] = 'more {C:attention}Wild{} cards in your deck, gain {C:attention}+2{} hand size.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 8,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.setting_blind  then
            if (function()
                local count = 0
                for _, playing_card in pairs(G.playing_cards or {}) do
                    if SMODS.get_enhancements(playing_card)["m_wild"] == true then
                        count = count + 1
                    end
                end
                return to_big(count) >= to_big(10)
            end)() then
                return {
                    
                    func = function()
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(2).." Hand Limit", colour = G.C.BLUE})
                        
                        G.hand:change_size(2)
                        return true
                    end
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if (function()
                local count = 0
                for _, playing_card in pairs(G.playing_cards or {}) do
                    if SMODS.get_enhancements(playing_card)["m_wild"] == true then
                        count = count + 1
                    end
                end
                return to_big(count) >= to_big(10)
            end)() then
                return {
                    
                    func = function()
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(2).." Hand Limit", colour = G.C.BLUE})
                        
                        G.hand:change_size(-2)
                        return true
                    end
                }
            end
        end
    end
}