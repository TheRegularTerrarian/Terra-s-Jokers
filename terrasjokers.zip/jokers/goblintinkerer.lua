SMODS.Joker{ --Goblin Tinkerer
    key = "goblintinkerer",
    config = {
        extra = {
            dollars = 2
        }
    },
    loc_txt = {
        ['name'] = 'Goblin Tinkerer',
        ['text'] = {
            [1] = 'When a card is scored, reduce its {C:attention}rank{} to {C:attention}2{} and lose {C:gold}$1{}.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 2,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },

    set_ability = function(self, card, initial)
        G.GAME.current_round.ranrank_card = { rank = 'Ace', id = 14 }
    end,

    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            assert(SMODS.change_base(context.other_card, nil, "2"))
            return {
                dollars = -card.ability.extra.dollars,
                extra = {
                message = "Reforged!",
                colour = G.C.BLUE
            }
        }
    end
end
}