
SMODS.Joker{ --Dreamweaver
    key = "dreamweaver",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Dreamweaver',
        ['text'] = {
            [1] = 'After playing a hand, if you are holding a {C:tarot}Tarot{} card, {C:attention}destroy{} it',
            [2] = 'and create a random {C:spectral}Spectral{} card. At the end of the round,',
            [3] = 'if you are holding no {C:attention}Consumables{}, create a random {C:tarot}Tarot{} card.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terrasjo_jokers"] = true, ["terrasjo_Coven_Jokers"] = true, ["terrasjo_terras_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
                local count = 0
                for _, consumable_card in pairs(G.consumeables.cards or {}) do
                    if consumable_card.ability.set == 'Tarot' then
                        count = count + 1
                    end
                end
                return to_big(count) >= to_big(1)
            end)() then
                local target_cards = {}
                for i, consumable in ipairs(G.consumeables.cards) do
                    if consumable.ability.set == "Tarot" then
                        table.insert(target_cards, consumable)
                    end
                end
                if #target_cards > 0 then
                    local card_to_destroy = pseudorandom_element(target_cards, pseudoseed('destroy_consumable'))
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            card_to_destroy:start_dissolve()
                            return true
                        end
                    }))
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Dreamwoven!", colour = G.C.RED})
                end
                for i = 1, math.min(1, G.consumeables.config.card_limit - #G.consumeables.cards) do
                    G.E_MANAGER:add_event(Event({
                        trigger = 'after',
                        delay = 0.4,
                        func = function()
                            play_sound('timpani')
                            SMODS.add_card({ set = 'Spectral', })                            
                            card:juice_up(0.3, 0.5)
                            return true
                        end
                    }))
                end
                delay(0.6)
                return {
                    message = created_consumable and localize('k_plus_spectral') or nil
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if to_big(#G.consumeables.cards) == to_big(1) then
                return {
                    func = function()
                        
                        for i = 1, math.min(1, G.consumeables.config.card_limit - #G.consumeables.cards) do
                            G.E_MANAGER:add_event(Event({
                                trigger = 'after',
                                delay = 0.4,
                                func = function()
                                    play_sound('timpani')
                                    SMODS.add_card({ set = 'Tarot', })                            
                                    card:juice_up(0.3, 0.5)
                                    return true
                                end
                            }))
                        end
                        delay(0.6)
                        
                        if created_consumable then
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_tarot'), colour = G.C.PURPLE})
                        end
                        return true
                    end
                }
            end
        end
    end
}