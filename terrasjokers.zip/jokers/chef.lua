
SMODS.Joker{ --Chef
    key = "chef",
    config = {
        extra = {
            hands = 1,
            Xmult = 2,
            y = 0,
            start_dissolve = 0,
            no = 0,
            var1 = 0,
            round = 0
        }
    },
    loc_txt = {
        ['name'] = 'Chef',
        ['text'] = {
            [1] = 'After using your last hand,',
            [2] = 'gain {C:attention}+1{} {C:blue}Hand{} and destroy this {C:attention}Joker{}.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 5,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if to_big(G.GAME.current_round.hands_left) > to_big(1) then
                local target_joker = card
                
                if target_joker then
                    target_joker.getting_sliced = true
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                            return true
                        end
                    }))
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Mixed!", colour = G.C.RED})
                end
                return {
                    
                    func = function()
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(1).." Hands", colour = G.C.GREEN})
                        
                        G.GAME.current_round.hands_left = G.GAME.current_round.hands_left + 1
                        return true
                    end
                }
            elseif to_big(#G.jokers.highlighted) == to_big(1) then
                return {
                    Xmult = 2
                }
            end
        end
    end
}