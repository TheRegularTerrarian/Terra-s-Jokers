SMODS.Joker{ --Chef
    key = "chef",
    config = {
        extra = {
            hands = 1,
            y = 0,
            start_dissolve = 0,
            round = 0
        }
    },
    loc_txt = {
        ['name'] = 'Chef',
        ['text'] = {
            [1] = 'After using your last hand,',
            [2] = 'gain {C:attention}+1{} {C:blue}Hand{} and destroy this {C:attention}Joker{}.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 5,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if G.GAME.current_round.hands_left == 0 then
                return {
                    func = function()
                        card:start_dissolve()
                        return true
                        end,
                        message = "Mixed!",
                        extra = {
                        func = function()
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.hands).." Hand", colour = G.C.GREEN})
                            G.GAME.current_round.hands_left = G.GAME.current_round.hands_left + card.ability.extra.hands
                            return true
                            end,
                            colour = G.C.GREEN
                        }
                    }
                end
            end
        end
}