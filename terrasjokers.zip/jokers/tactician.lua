SMODS.Joker{ --Tactician
    key = "tactician",
    config = {
        extra = {
            Mobilise = 0,
            start_dissolve = 0,
            y = 0,
            no = 0,
            var1 = 0,
            ignore = 0
        }
    },
    loc_txt = {
        ['name'] = 'Tactician',
        ['text'] = {
            [1] = 'When a {C:attention}Blind{} is selected, if you have {C:attention}destroyed 10{} or more',
            [2] = 'cards while owning {C:red}Tactician{}, {C:attention}destroy{} self and create {C:red}War{}.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terrasjo_jokers"] = true, ["terrasjo_terras_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.remove_playing_cards  then
            return {
                func = function()
                    card.ability.extra.Mobilise = (card.ability.extra.Mobilise) + 1
                    return true
                    end
                }
            end
            if context.setting_blind  then
                if (card.ability.extra.Mobilise or 0) >= 10 then
                    return {
                        func = function()
                            local destructable_jokers = {}
                            for i, joker in ipairs(G.jokers.cards) do
                                if joker ~= card and not SMODS.is_eternal(joker) and not joker.getting_sliced then
                                    table.insert(destructable_jokers, joker)
                                end
                            end
                            local target_joker = #destructable_jokers > 0 and pseudorandom_element(destructable_jokers, pseudoseed('destroy_joker')) or nil
                            
                            if target_joker then
                                target_joker.getting_sliced = true
                                G.E_MANAGER:add_event(Event({
                                func = function()
                                    target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                                    return true
                                    end
                                }))
                                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Transformed!", colour = G.C.RED})
                            end
                            return true
                            end,
                            extra = {
                            func = function()
                                
                                local created_joker = true
                                G.E_MANAGER:add_event(Event({
                                func = function()
                                    local joker_card = SMODS.add_card({ set = 'Joker', key = 'j_terrasjo_war' })
                                    if joker_card then
                                        joker_card:set_edition("e_negative", true)
                                        
                                    end
                                    
                                    return true
                                    end
                                }))
                                
                                if created_joker then
                                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_joker'), colour = G.C.BLUE})
                                end
                                return true
                                end,
                                colour = G.C.BLUE
                            }
                        }
                    end
                end
            end
}