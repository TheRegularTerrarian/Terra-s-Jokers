
SMODS.Joker{ --Tavern Keeper
    key = "tavernkeeper",
    config = {
        extra = {
            pb_mult_02fe9d64 = 2,
            dollars = 1,
            perma_mult = 0
        }
    },
    loc_txt = {
        ['name'] = 'Tavern Keeper',
        ['text'] = {
            [1] = 'Scored {C:attention}Face{} cards permanently give {C:red}+2{} Mult but cost {C:gold}$1{} to play.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 3,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_face() then
                context.other_card.ability.perma_mult = context.other_card.ability.perma_mult or 0
                context.other_card.ability.perma_mult = context.other_card.ability.perma_mult + card.ability.extra.pb_mult_02fe9d64
                return {
                    extra = { message = localize('k_upgrade_ex'), colour = G.C.MULT }, card = card,
                    extra = {
                        
                        func = function()
                            
                            local current_dollars = G.GAME.dollars
                            local target_dollars = G.GAME.dollars - card.ability.extra.dollars
                            local dollar_value = target_dollars - current_dollars
                            ease_dollars(dollar_value)
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(card.ability.extra.dollars), colour = G.C.MONEY})
                            return true
                        end,
                        colour = G.C.MONEY
                    }
                }
            end
        end
    end
}