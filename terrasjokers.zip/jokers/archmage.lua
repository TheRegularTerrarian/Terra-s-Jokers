
SMODS.Joker{ --Archmage
    key = "archmage",
    config = {
        extra = {
            xmultvar = 1
        }
    },
    loc_txt = {
        ['name'] = 'Archmage',
        ['text'] = {
            [1] = 'Gain {X:red,C:white}X1{} Mult. After winning a round,',
            [2] = 'permanently gain {X:red,C:white}X0.1{} Mult. Gain {X:red,C:white}X0.2{} more',
            [3] = 'Mult if you have selected another {C:tarot}Coven{} {C:attention}Joker{}.',
            [4] = '{C:inactive}(Currently{} {X:red,C:white}X#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = false,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terrasjo_jokers"] = true, ["terrasjo_Coven_Jokers"] = true, ["terrasjo_terras_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.xmultvar, card.ability.extra.CovenJoker}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = card.ability.extra.xmultvar
            }
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if not (#G.jokers.highlighted > 0 and G.jokers.highlighted[1].config.center.key == "j_terrasjo_hexmaster, terrasjo_witch, terrasjo_bulwark, terrasjo_jinx, terrasjo_ritualist, terrasjo_conjurer, terrasjo_potionmaster, terrasjo_poisoner, terrasjo_necromancer, terrasjo_voodoomaster, terrasjo_wildling, terrasjo_dreamweaver, terrasjo_medusa, terrasjo_enchanter, terrasjo_illusionist, terrasjo_blight") then
                return {
                    func = function()
                        card.ability.extra.xmultvar = (card.ability.extra.xmultvar) + 0.1
                        return true
                    end
                }
            elseif #G.jokers.highlighted > 0 and G.jokers.highlighted[1].config.center.key == "j_terrasjo_hexmaster, terrasjo_witch, terrasjo_bulwark, terrasjo_jinx, terrasjo_ritualist, terrasjo_conjurer, terrasjo_potionmaster, terrasjo_poisoner, terrasjo_necromancer, terrasjo_voodoomaster, terrasjo_wildling, terrasjo_dreamweaver, terrasjo_medusa, terrasjo_enchanter, terrasjo_illusionist, terrasjo_blight" then
                return {
                    func = function()
                        card.ability.extra.xmultvar = (card.ability.extra.xmultvar) + 0.3
                        return true
                    end
                }
            end
        end
    end
}