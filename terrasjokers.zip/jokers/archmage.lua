SMODS.Joker{ --Archmage
    key = "archmage",
    config = {
        extra = {
            xmultvar = 1,
            CovenJoker = 'j_terrasjo_hexmaster, j_terrasjo_witch, j_terrasjo_bulwark, j_terrasjo_jinx, j_terrasjo_ritualist, j_terrasjo_conjurer, j_terrasjo_potionmaster, j_terrasjo_poisoner, j_terrasjo_necromancer, j_terrasjo_voodoomaster, j_terrasjo_wildling, j_terrasjo_dreamweaver, j_terrasjo_medusa, j_terrasjo_enchanter, j_terrasjo_illusionist, j_terrasjo_blight'
        }
    },
    loc_txt = {
        ['name'] = 'Archmage',
        ['text'] = {
            [1] = 'Gain {X:red,C:white}X1{} Mult. After winning a round,',
            [2] = 'permanently gain {X:red,C:white}X0.1{} Mult. Gain {X:red,C:white}X0.2{}',
            [3] = 'Mult if you own another {C:tarot}Coven{} {C:attention}Joker{}.',
            [4] = 'When a {C:tarot}Coven{} {C:attention}Joker{} is triggered, gain {X:red,C:white}X0.1{}.',
            [5] = '{C:inactive}(Currently{} {X:red,C:white}X#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = false,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terrasjo_jokers"] = true, ["terrasjo_Coven_Jokers"] = true, ["terrasjo_terras_jokers"] = true },

    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.xmultvar}}
    end,

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = card.ability.extra.xmultvar
            }
        end
    if context.end_of_round and context.game_over == false and context.main_eval  then
        if (function()
            for i = 1, #G.jokers.cards do
                if G.jokers.cards[i].config.center.key == "j_terrasjo_hexmaster, terrasjo_witch, terrasjo_bulwark, terrasjo_jinx, terrasjo_ritualist, terrasjo_conjurer, terrasjo_potionmaster, terrasjo_poisoner, terrasjo_necromancer, terrasjo_voodoomaster, terrasjo_wildling, terrasjo_dreamweaver, terrasjo_medusa, terrasjo_enchanter, terrasjo_illusionist, terrasjo_blight" then
                    return true
                    end
                end
                return false
                end)() then
                    return {
                        func = function()
                            card.ability.extra.xmultvar = (card.ability.extra.xmultvar) + 0.2
                            return true
                            end
                        }
                    else
                        return {
                            func = function()
                                card.ability.extra.xmultvar = (card.ability.extra.xmultvar) + 0.1
                                return true
                                end
                            }
                        end
                    end
                    if context.other_joker  then
                        if (function()
                            for i = 1, #G.jokers.cards do
                                if G.jokers.cards[i].config.center.key == "j_terrasjo_hexmaster, terrasjo_witch, terrasjo_bulwark, terrasjo_jinx, terrasjo_ritualist, terrasjo_conjurer, terrasjo_potionmaster, terrasjo_poisoner, terrasjo_necromancer, terrasjo_voodoomaster, terrasjo_wildling, terrasjo_dreamweaver, terrasjo_medusa, terrasjo_enchanter, terrasjo_illusionist, terrasjo_blight" then
                                    return true
                                    end
                                end
                                return false
                                end)() then
                                    return {
                                        func = function()
                                            card.ability.extra.xmultvar = (card.ability.extra.xmultvar) + 0.1
                                            return true
                                            end
                                        }
                                    end
                                end
                            end
}