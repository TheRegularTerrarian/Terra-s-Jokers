
SMODS.Joker{ --Wildling
    key = "wildling",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Wildling',
        ['text'] = {
            [1] = '{C:attention}Enhances{} all played cards in {C:attention}first played hand{} of round to {C:attention}Wild{}.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terrasjo_jokers"] = true, ["terrasjo_Coven_Jokers"] = true, ["terrasjo_terras_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if G.GAME.current_round.hands_played == 0 then
                context.other_card:set_ability(G.P_CENTERS.[object Object])
                return {
                    message = "Wild!"
                }
            end
        end
    end
}