SMODS.Joker{ --Kettle
    key = "kettle",
    config = {
        extra = {
            Xmult = 2,
            mult = 5
        }
    },
    loc_txt = {
        ['name'] = 'Kettle',
        ['text'] = {
            [1] = '{C:red}+5{} Mult. Creates a random tag when a {C:blue}Spectral{} {C:attention}Card{} is used.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 8,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
                for i = 1, #G.jokers.cards do
                    if G.jokers.cards[i].config.center.key == "j_terrasjo_ovenleader" then
                        return true
                        end
                    end
                    return false
                    end)() then
                        return {
                            Xmult = card.ability.extra.Xmult
                        }
                    else
                        return {
                            mult = card.ability.extra.mult
                        }
                    end
                end
                if context.using_consumeable  then
                    if context.consumeable and context.consumeable.ability.set == 'Spectral' then
                        return {
                            func = function()
                                G.E_MANAGER:add_event(Event({
                                func = function()
                                    local selected_tag = pseudorandom_element(G.P_TAGS, pseudoseed("create_tag")).key
                                    local tag = Tag(selected_tag)
                                    if tag.name == "Orbital Tag" then
                                        local _poker_hands = {}
                                        for k, v in pairs(G.GAME.hands) do
                                            if v.visible then
                                                _poker_hands[#_poker_hands + 1] = k
                                            end
                                        end
                                        tag.ability.orbital_hand = pseudorandom_element(_poker_hands, "jokerforge_orbital")
                                    end
                                    tag:set_ability()
                                    add_tag(tag)
                                    play_sound('holo1', 1.2 + math.random() * 0.1, 0.4)
                                    return true
                                    end
                                }))
                                return true
                                end,
                                message = "Boiled!"
                            }
                        end
                    end
                end
}