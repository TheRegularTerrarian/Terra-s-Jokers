
SMODS.Joker{ --Surveillance
    key = "surveillance",
    config = {
        extra = {
            hand_size0 = 2,
            hand_size = 2
        }
    },
    loc_txt = {
        ['name'] = 'Surveillance',
        ['text'] = {
            [1] = 'Gain {C:attention}+2{} hand size on the final hand of the round.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 9,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if to_big(G.GAME.current_round.hands_left) == to_big(1) then
                return {
                    
                    func = function()
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Observing", colour = G.C.BLUE})
                        
                        G.hand:change_size(2)
                        return true
                    end
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if to_big(G.GAME.current_round.hands_left) == to_big(0) then
                return {
                    
                    func = function()
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "No longer watching", colour = G.C.BLUE})
                        
                        G.hand:change_size(-2)
                        return true
                    end
                }
            end
        end
    end
}