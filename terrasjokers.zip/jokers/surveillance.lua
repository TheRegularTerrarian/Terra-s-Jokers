SMODS.Joker{ --Surveillance
    key = "surveillance",
    config = {
        extra = {
            hand_size = 1,
            hand_size2 = 1,
            hand_size3 = 8
        }
    },
    loc_txt = {
        ['name'] = 'Surveillance',
        ['text'] = {
            [1] = '{C:attention}+1{} hand size if you have',
            [2] = '{C:attention}2{} or less hands remaining.',
            [3] = '{C:attention}+1{} hand size if you have',
            [4] = '{C:attention}0{} discards remaining.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 9,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.hand_drawn  then
            if (G.GAME.current_round.hands_left <= 2 and G.hand.config.card_limit <= 9) then
                return {
                    func = function()
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Overseen!", colour = G.C.BLUE})
                        G.hand:change_size(card.ability.extra.hand_size)
                        return true
                        end
                    }
                elseif (G.GAME.current_round.discards_left == 0 and G.hand.config.card_limit <= 9) then
                    return {
                        func = function()
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Overseen!", colour = G.C.BLUE})
                            G.hand:change_size(card.ability.extra.hand_size2)
                            return true
                            end
                        }
                    end
                end
            if context.end_of_round and context.game_over == false and context.main_eval  then
                return {
                    func = function()
                        local current_hand_size = G.hand.config.card_limit
                        local target_hand_size = card.ability.extra.hand_size3
                        local difference = target_hand_size - current_hand_size
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "No longer watching.", colour = G.C.BLUE})
                            G.hand:change_size(difference)
                                return true
                                end
                            }
                        end
                    end
}