SMODS.Joker{ --Surveillance
    key = "surveillance",
    config = {
        extra = {
            hand_size = 1,
            hand_size2 = 1,
            hand_size3 = 1,
            hand_size4 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Surveillance',
        ['text'] = {
            [1] = '{C:attention}+1{} hand size if you have',
            [2] = '{C:attention}2{} or less hands remaining.',
            [3] = '{C:attention}+1{} hand size if you have',
            [4] = '{C:attention}0{} discards remaining.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 9,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.hand_drawn  then
            if G.GAME.current_round.hands_left <= 2 then
                return {
                    func = function()
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Overseen!", colour = G.C.BLUE})
                        G.hand:change_size(card.ability.extra.hand_size)
                        return true
                        end
                    }
                elseif G.GAME.current_round.discards_left == 0 then
                    return {
                        func = function()
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Overseen!", colour = G.C.BLUE})
                            G.hand:change_size(card.ability.extra.hand_size2)
                            return true
                            end
                        }
                    end
                end
            if context.end_of_round and context.game_over == false and context.main_eval  then
                if G.GAME.current_round.hands_left <= 2 then
                    return {
                        func = function()
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "No longer watching.", colour = G.C.RED})
                            G.hand:change_size(-card.ability.extra.hand_size3)
                            return true
                            end
                        }
                    elseif G.GAME.current_round.discards_left == 0 then
                        return {
                            func = function()
                                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(card.ability.extra.hand_size4).." Hand Size", colour = G.C.RED})
                                G.hand:change_size(-card.ability.extra.hand_size4)
                                return true
                                end
                            }
                        end
                    end
                end
}