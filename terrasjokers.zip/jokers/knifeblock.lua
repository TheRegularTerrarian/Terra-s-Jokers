SMODS.Joker{ --Knife Block
    key = "knifeblock",
    config = {
        extra = {
            chips = 50,
            mult = 8,
            Xmult = 1.2,
            dollars = 3,
            Xmult2 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Knife Block',
        ['text'] = {
            [1] = 'If {C:attention}poker hand{} is a {C:attention}#1#{},',
            [2] = 'gain {C:blue}+50{} Chips, {C:red}+8{} Mult, {X:red,C:white}X1.2{} Mult,',
            [3] = 'and {C:gold}$3{}. Poker hand changes at end of round'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 8,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },

    loc_vars = function(self, info_queue, card)
        
        return {vars = {localize((G.GAME.current_round.pokervar_hand or 'High Card'), 'poker_hands')}}
    end,

    set_ability = function(self, card, initial)
        G.GAME.current_round.pokervar_hand = 'High Card'
    end,

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if context.scoring_name == G.GAME.current_round.pokervar_hand then
                return {
                    chips = card.ability.extra.chips,
                    extra = {
                    mult = card.ability.extra.mult,
                    extra = {
                    Xmult = card.ability.extra.Xmult,
                    extra = {
                    dollars = card.ability.extra.dollars,
                    colour = G.C.MONEY
                }
            }
        }
    }
elseif (function()
    for i = 1, #G.jokers.cards do
        if G.jokers.cards[i].config.center.key == "j_terrasjo_ovenleader" then
            return true
            end
        end
        return false
        end)() then
            return {
                Xmult = card.ability.extra.Xmult2
            }
        end
    end
if context.end_of_round and context.game_over == false and context.main_eval  then
    local pokervar_hands = {}
    for handname, _ in pairs(G.GAME.hands) do
        if G.GAME.hands[handname].visible then
            pokervar_hands[#pokervar_hands + 1] = handname
        end
    end
    if pokervar_hands[1] then
        G.GAME.current_round.pokervar_hand = pseudorandom_element(pokervar_hands, pseudoseed('pokervar' .. G.GAME.round_resets.ante))
    end
end
end
}