
SMODS.Joker{ --The Destroyer
    key = "thedestroyer",
    config = {
        extra = {
            n = 0
        }
    },
    loc_txt = {
        ['name'] = 'The Destroyer',
        ['text'] = {
            [1] = '{C:attention}Enhance{} all discarded cards to Foil. Destroys all',
            [2] = 'cards played in first and last hand of round.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 4,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 10,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.discard  then
            if not ((function()
                local enhancements = SMODS.get_enhancements(context.other_card)
                for k, v in pairs(enhancements) do
                    if v then
                        return true
                    end
                end
                return false
            end)()) then
                return {
                    func = function()
                        context.other_card:set_edition("e_foil", true)
                    end,
                    message = "Card Modified!"
                }
            end
        end
        if context.destroy_card and context.destroy_card.should_destroy  then
            return { remove = true }
        end
        if context.individual and context.cardarea == G.play  then
            context.other_card.should_destroy = false
            if G.GAME.current_round.hands_played == 0 then
                context.other_card.should_destroy = true
                return {
                    message = "Destroyed!"
                }
                elseif to_big(G.GAME.current_round.hands_left) == to_big(1) then
                    context.other_card.should_destroy = true
                    return {
                        message = "Destroyed!"
                    }
                end
            end
        end
    }