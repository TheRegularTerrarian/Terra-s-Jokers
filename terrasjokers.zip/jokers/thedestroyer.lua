SMODS.Joker{ --The Destroyer
    key = "thedestroyer",
    config = {
        extra = {
            n = 0
        }
    },
    loc_txt = {
        ['name'] = 'The Destroyer',
        ['text'] = {
            [1] = '{C:attention}Enhance{} all discarded cards to Foil. Destroys all',
            [2] = 'cards played in first and last hand of round.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 8,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 10,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.discard  then
            if not ((function()
                local enhancements = SMODS.get_enhancements(context.other_card)
                for k, v in pairs(enhancements) do
                    if v then
                        return true
                        end
                    end
                    return false
                    end)()) then
                    end
                end
                if context.individual and context.cardarea == G.play  then
                    if G.GAME.current_round.hands_played == 0 then
                    elseif G.GAME.current_round.hands_left == 1 then
                    end
                end
            end
}