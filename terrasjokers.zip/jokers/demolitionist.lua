SMODS.Joker{ --Demolitionist
    key = "demolitionist",
    config = {
        extra = {
            start_dissolve = 0,
            n = 0
        }
    },
    loc_txt = {
        ['name'] = 'Demolitionist',
        ['text'] = {
            [1] = 'When discarding {C:attention}1{} card, {C:attention}destroy{} it.',
            [2] = 'When discarding {C:attention}5{} cards, {C:attention}destroy{}',
            [3] = 'them and {C:attention}destroy{} self.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 7,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.discard  then
            if #context.full_hand == 1 then
                return {
                    remove = true,
                    message = "Destroyed!"
                }
            elseif #context.full_hand == 5 then
                return {
                    remove = true,
                    message = "Destroyed!",
                    extra = {
                    func = function()
                        card:start_dissolve()
                        return true
                        end,
                        colour = G.C.RED
                    }
                }
            end
        end
    end
}