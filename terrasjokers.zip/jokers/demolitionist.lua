
SMODS.Joker{ --Demolitionist
    key = "demolitionist",
    config = {
        extra = {
            n = 0,
            explode = 0,
            yes = 0,
            var1 = 0
        }
    },
    loc_txt = {
        ['name'] = 'Demolitionist',
        ['text'] = {
            [1] = 'When discarding {C:attention}1{} card, {C:attention}destroy{} it.',
            [2] = 'When discarding {C:attention}5{} cards, {C:attention}destroy{}',
            [3] = 'them and {C:attention}destroy{} self.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 7,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.discard  then
            if (to_big(#context.full_hand) == to_big(1) and not (to_big(#context.full_hand) == to_big(5))) then
                return {
                    remove = true,
                    message = "Boom!"
                }
            elseif (to_big(#context.full_hand) == to_big(5) and not (to_big(#context.full_hand) <= to_big(4))) then
                return {
                    remove = true,
                    message = "Boom!",
                    extra = {
                        func = function()
                            local target_joker = card
                            
                            if target_joker then
                                if target_joker.ability.eternal then
                                    target_joker.ability.eternal = nil
                                end
                                target_joker.getting_sliced = true
                                G.E_MANAGER:add_event(Event({
                                    func = function()
                                        target_joker:explode({G.C.RED}, nil, 1.6)
                                        return true
                                    end
                                }))
                                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Demolished!", colour = G.C.RED})
                            end
                            return true
                        end,
                        colour = G.C.RED
                    }
                }
            end
        end
    end
}