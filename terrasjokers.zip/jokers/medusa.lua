SMODS.Joker{ --Medusa
    key = "medusa",
    config = {
        extra = {
            deck = 0,
            y = 0,
            n = 0
        }
    },
    loc_txt = {
        ['name'] = 'Medusa',
        ['text'] = {
            [1] = 'When a card is {C:attention}destroyed{}, add a {C:attention}Stone{} card to your deck.',
            [2] = 'If played hand includes a {C:attention}Stone{} card, give {C:attention}1{} random {C:negative}Negative{} {C:tarot}Tarot{} card.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terrasjo_jokers"] = true, ["terrasjo_Coven_Jokers"] = true, ["terrasjo_terras_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.remove_playing_cards  then
        end
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
                local count = 0
                for _, playing_card in pairs(context.scoring_hand or {}) do
                    if SMODS.get_enhancements(playing_card)["m_stone"] == true then
                        count = count + 1
                    end
                end
                return count >= 1
                end)() then
                    for i = 1, 1 do
                        G.E_MANAGER:add_event(Event({
                        trigger = 'after',
                        delay = 0.4,
                        func = function()
                            if G.consumeables.config.card_limit > #G.consumeables.cards + G.GAME.consumeable_buffer then
                                G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                            end
                            
                            play_sound('timpani')
                            SMODS.add_card({ set = 'Tarot', edition = 'e_negative', soulable = true, })                            
                            card:juice_up(0.3, 0.5)
                            return true
                            end
                        }))
                    end
                    delay(0.6)
                    return {
                        message = created_consumable and localize('k_plus_tarot') or nil
                    }
                end
            end
        end
}