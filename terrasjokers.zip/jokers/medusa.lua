
SMODS.Joker{ --Medusa
    key = "medusa",
    config = {
        extra = {
            deck = 0,
            y = 0,
            n = 0
        }
    },
    loc_txt = {
        ['name'] = 'Medusa',
        ['text'] = {
            [1] = 'When a card is {C:attention}destroyed{}, add a {C:attention}Stone{} card to your deck.',
            [2] = 'If played hand includes a {C:attention}Stone{} card, give {C:attention}1{} random {C:negative}Negative{} {C:tarot}Tarot{} card.'
            },
            ['unlock'] = {
                [1] = 'Unlocked by default.'
            }
        },
        pos = {
            x = 9,
            y = 5
        },
        display_size = {
            w = 71 * 1, 
            h = 95 * 1
        },
        cost = 5,
        rarity = 2,
        blueprint_compat = true,
        eternal_compat = true,
        perishable_compat = true,
        unlocked = true,
        discovered = false,
        atlas = 'CustomJokers',
        pools = { ["terrasjo_terrasjo_jokers"] = true, ["terrasjo_Coven_Jokers"] = true, ["terrasjo_terras_jokers"] = true },
        
        calculate = function(self, card, context)
            if context.remove_playing_cards  then
                local card_front = pseudorandom_element(G.P_CARDS, pseudoseed('add_card_hand'))
                local new_card = create_playing_card({
                    front = card_front,
                    center = G.P_CENTERS.m_stone
                }, G.discard, true, false, nil, true)
                
                base_card:set_seal(pseudorandom_element({'Gold','Red','Blue','Purple'}, pseudoseed('add_card_hand_seal')), true)
                
                base_card:set_edition(pseudorandom_element({'e_foil','e_holo','e_polychrome','e_negative'}, pseudoseed('add_card_hand_edition')), true)
                
                G.E_MANAGER:add_event(Event({
                    func = function()
                        new_card:start_materialize()
                        G.play:emplace(new_card)
                        return true
                    end
                }))
                return {
                    func = function()
                        G.E_MANAGER:add_event(Event({
                            func = function()
                                G.deck.config.card_limit = G.deck.config.card_limit + 1
                                return true
                            end
                        }))
                        draw_card(G.play, G.deck, 90, 'up')
                        SMODS.calculate_context({ playing_card_added = true, cards = { new_card } })
                    end,
                    message = "Stoned!"
                }
            end
            if context.cardarea == G.jokers and context.joker_main  then
                for i = 1, 1 do
                    G.E_MANAGER:add_event(Event({
                        trigger = 'after',
                        delay = 0.4,
                        func = function()
                            if G.consumeables.config.card_limit > #G.consumeables.cards + G.GAME.consumeable_buffer then
                                G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                            end
                            
                            play_sound('timpani')
                            SMODS.add_card({ set = 'Tarot', edition = 'e_negative', soulable = true, })                            
                            card:juice_up(0.3, 0.5)
                            return true
                        end
                    }))
                end
                delay(0.6)
                return {
                    message = created_consumable and localize('k_plus_tarot') or nil
                }
            end
        end
    }