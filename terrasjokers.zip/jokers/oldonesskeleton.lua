
SMODS.Joker{ --Old Ones Skeleton
    key = "oldonesskeleton",
    config = {
        extra = {
            chips = 20,
            mult = 5,
            chips2 = 40,
            mult2 = 10,
            chips3 = 80,
            mult3 = 20,
            chips4 = 160,
            mult4 = 40,
            chips5 = 320,
            mult5 = 80,
            chips6 = 640,
            mult6 = 160
        }
    },
    loc_txt = {
        ['name'] = 'Old Ones Skeleton',
        ['text'] = {
            [1] = '{C:blue}+20{} Chips and {C:red}+5{} Mult. Gives double for each',
            [2] = '{C:attention}Old One\'s Skeleton{} owned. {C:attention}Eternal{}.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 8,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 1,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' and args.source ~= 'buf' and args.source ~= 'jud' and args.source ~= 'rif' 
            or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    set_ability = function(self, card, initial)
        card:set_eternal(true)
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if ((function()
                local count = 0
                for _, joker_owned in pairs(G.jokers.cards or {}) do
                    if joker_owned.config.center.rarity == 1 then
                        count = count + 1
                    end
                end
                return to_big(count) == to_big(1)
            end)() and (function()
                for i, v in pairs(G.jokers.cards) do
                    if v.config.center.key == "j_terrasjo_oldonesskeleton" then 
                        return true
                    end
                end
            end)()) then
                return {
                    chips = card.ability.extra.chips,
                    extra = {
                        mult = card.ability.extra.mult
                    }
                }
            elseif ((function()
                local count = 0
                for _, joker_owned in pairs(G.jokers.cards or {}) do
                    if joker_owned.config.center.rarity == 1 then
                        count = count + 1
                    end
                end
                return to_big(count) == to_big(2)
            end)() and (function()
                for i, v in pairs(G.jokers.cards) do
                    if v.config.center.key == "j_terrasjo_oldonesskeleton" then 
                        return true
                    end
                end
            end)()) then
                return {
                    chips = card.ability.extra.chips2,
                    extra = {
                        mult = card.ability.extra.mult2
                    }
                }
            elseif ((function()
                local count = 0
                for _, joker_owned in pairs(G.jokers.cards or {}) do
                    if joker_owned.config.center.rarity == 1 then
                        count = count + 1
                    end
                end
                return to_big(count) == to_big(3)
            end)() and (function()
                for i, v in pairs(G.jokers.cards) do
                    if v.config.center.key == "j_terrasjo_oldonesskeleton" then 
                        return true
                    end
                end
            end)()) then
                return {
                    chips = card.ability.extra.chips3,
                    extra = {
                        mult = card.ability.extra.mult3
                    }
                }
            elseif ((function()
                local count = 0
                for _, joker_owned in pairs(G.jokers.cards or {}) do
                    if joker_owned.config.center.rarity == 1 then
                        count = count + 1
                    end
                end
                return to_big(count) == to_big(4)
            end)() and (function()
                for i, v in pairs(G.jokers.cards) do
                    if v.config.center.key == "j_terrasjo_oldonesskeleton" then 
                        return true
                    end
                end
            end)()) then
                return {
                    chips = card.ability.extra.chips4,
                    extra = {
                        mult = card.ability.extra.mult4
                    }
                }
            elseif ((function()
                local count = 0
                for _, joker_owned in pairs(G.jokers.cards or {}) do
                    if joker_owned.config.center.rarity == 1 then
                        count = count + 1
                    end
                end
                return to_big(count) == to_big(5)
            end)() and (function()
                for i, v in pairs(G.jokers.cards) do
                    if v.config.center.key == "j_terrasjo_oldonesskeleton" then 
                        return true
                    end
                end
            end)()) then
                return {
                    chips = card.ability.extra.chips5,
                    extra = {
                        mult = card.ability.extra.mult5
                    }
                }
            elseif ((function()
                local count = 0
                for _, joker_owned in pairs(G.jokers.cards or {}) do
                    if joker_owned.config.center.rarity == 1 then
                        count = count + 1
                    end
                end
                return to_big(count) == to_big(6)
            end)() and (function()
                for i, v in pairs(G.jokers.cards) do
                    if v.config.center.key == "j_terrasjo_oldonesskeleton" then 
                        return true
                    end
                end
            end)()) then
                return {
                    chips = card.ability.extra.chips6,
                    extra = {
                        mult = card.ability.extra.mult6
                    }
                }
            end
        end
    end
}