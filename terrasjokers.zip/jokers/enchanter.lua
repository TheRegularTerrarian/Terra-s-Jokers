
SMODS.Joker{ --Enchanter
    key = "enchanter",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Enchanter',
        ['text'] = {
            [1] = 'When a {C:attention}Face{} card is played, change its {C:attention}rank{} to {C:attention}4{}.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terrasjo_jokers"] = true, ["terrasjo_Coven_Jokers"] = true, ["terrasjo_terras_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_face() then
                local scored_card = context.other_card
                G.E_MANAGER:add_event(Event({
                    func = function()
                        
                        assert(SMODS.change_base(scored_card, nil, "4"))
                        card_eval_status_text(scored_card, 'extra', nil, nil, nil, {message = "Altered!", colour = G.C.ORANGE})
                        return true
                    end
                }))
            end
        end
    end
}