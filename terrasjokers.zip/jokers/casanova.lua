SMODS.Joker{ --Casanova
    key = "casanova",
    config = {
        extra = {
            Xmult = 2,
            shatter = 0,
            n = 0,
            no = 0,
            var1 = 0
        }
    },
    loc_txt = {
        ['name'] = 'Casanova',
        ['text'] = {
            [1] = 'If played hand contains only {C:attention}1{} card, {C:attention}enhance{} it to {C:attention}Glass{}.',
            [2] = '{C:attention}Glass Cards{} give {X:red,C:white}X2{} Mult when scored.',
            [3] = 'When a {C:attention}Glass Card{} breaks, {C:attention}destroy{} self.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terrasjo_jokers"] = true, ["terrasjo_Coven_Jokers"] = true },

    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_glass"] == true then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            else
            end
        end
        if context.remove_playing_cards  then
            if (function()
                for k, removed_card in ipairs(context.removed) do
                    if removed_card.shattered then
                        return true
                        end
                    end
                    return false
                    end)() then
                        return {
                            func = function()
                                local destructable_jokers = {}
                                for i, joker in ipairs(G.jokers.cards) do
                                    if joker ~= card and not SMODS.is_eternal(joker) and not joker.getting_sliced then
                                        table.insert(destructable_jokers, joker)
                                    end
                                end
                                local target_joker = #destructable_jokers > 0 and pseudorandom_element(destructable_jokers, pseudoseed('destroy_joker')) or nil
                                
                                if target_joker then
                                    target_joker.getting_sliced = true
                                    G.E_MANAGER:add_event(Event({
                                    func = function()
                                        target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                                        return true
                                        end
                                    }))
                                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Lifelinked!", colour = G.C.RED})
                                    end
                                    return true
                                    end
                                }
                            end
                        end
                    end
}