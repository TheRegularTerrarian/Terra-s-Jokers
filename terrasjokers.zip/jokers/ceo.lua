SMODS.Joker{ --CEO
    key = "ceo",
    config = {
        extra = {
            currentmoney = 0
        }
    },
    loc_txt = {
        ['name'] = 'CEO',
        ['text'] = {
            [1] = '{C:blue}+1{} Chips and {C:red}+1{} Mult per {C:gold}$1{} held.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 9,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                chips = G.GAME.dollars,
                extra = {
                mult = G.GAME.dollars
            }
        }
    end
end
}