
SMODS.Joker{ --Soul Collector
    key = "soulcollector",
    config = {
        extra = {
            Souls = 0,
            start_dissolve = 0,
            y = 0,
            no = 0,
            var1 = 0,
            ignore = 0
        }
    },
    loc_txt = {
        ['name'] = 'Soul Collector',
        ['text'] = {
            [1] = 'When a {C:attention}Blind{} is selected, if you have beaten {C:attention}6 Boss Blinds{}',
            [2] = 'while owning {C:red}Soul Collector{}, {C:attention}destroy{} self and create {C:red}Death{}.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terrasjo_jokers"] = true, ["terrasjo_terras_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Souls}}
    end,
    
    calculate = function(self, card, context)
        if context.end_of_round and context.main_eval and G.GAME.blind.boss  then
            return {
                func = function()
                    card.ability.extra.Souls = (card.ability.extra.Souls) + 1
                    return true
                end
            }
        end
        if context.setting_blind  then
            if to_big((card.ability.extra.Souls or 0)) >= to_big(6) then
                return {
                    func = function()
                        local target_joker = card
                        
                        if target_joker then
                            target_joker.getting_sliced = true
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                                    return true
                                end
                            }))
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Transformed!", colour = G.C.RED})
                        end
                        return true
                    end,
                    extra = {
                        func = function()
                            
                            local created_joker = true
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    local joker_card = SMODS.add_card({ set = 'Joker', key = 'j_terrasjo_death' })
                                    if joker_card then
                                        
                                        
                                    end
                                    
                                    return true
                                end
                            }))
                            
                            if created_joker then
                                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_joker'), colour = G.C.BLUE})
                            end
                            return true
                        end,
                        colour = G.C.BLUE
                    }
                }
            end
        end
    end
}