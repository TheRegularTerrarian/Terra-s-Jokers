
SMODS.Joker{ --Toaster
    key = "toaster",
    config = {
        extra = {
            xmult0 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Toaster',
        ['text'] = {
            [1] = '{C:attention}Destroy{} all triggered cards',
            [2] = 'in the first {C:blue}Hand{} of the round'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 3,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.destroy_card and context.destroy_card.should_destroy  then
            return { remove = true }
        end
        if context.individual and context.cardarea == G.play  then
            context.other_card.should_destroy = false
            if G.GAME.current_round.hands_played == 0 then
                context.other_card.should_destroy = true
                return {
                    message = "Toasted!"
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            if to_big(#G.jokers.highlighted) == to_big(1) then
                return {
                    Xmult = 2
                }
            end
        end
    end
}