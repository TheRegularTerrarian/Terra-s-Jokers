
SMODS.Joker{ --Waiter
    key = "waiter",
    config = {
        extra = {
            Xmult = 2,
            n = 0
        }
    },
    loc_txt = {
        ['name'] = 'Waiter',
        ['text'] = {
            [1] = 'If played {C:blue}Hand{} contains 5 scoring',
            [2] = 'cards, create a random {C:purple}Tarot{} card.',
            [3] = 'When 2 or less cards are {C:red}discarded{},',
            [4] = 'create a random {C:purple}Tarot{} card.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 1,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if to_big(#context.scoring_hand) == to_big(5) then
                for i = 1, math.min([object Object], G.consumeables.config.card_limit - #G.consumeables.cards) do
                    G.E_MANAGER:add_event(Event({
                        trigger = 'after',
                        delay = 0.4,
                        func = function()
                            play_sound('timpani')
                            SMODS.add_card({ set = 'Tarot', })                            
                            card:juice_up(0.3, 0.5)
                            return true
                        end
                    }))
                end
                delay(0.6)
                return {
                    message = created_consumable and localize('k_plus_tarot') or nil
                }
            elseif to_big(#G.jokers.highlighted) == to_big(1) then
                return {
                    Xmult = 2
                }
            end
        end
        if context.pre_discard  then
            if to_big(#context.full_hand) <= to_big(2) then
                return {
                    func = function()
                        
                        for i = 1, math.min([object Object], G.consumeables.config.card_limit - #G.consumeables.cards) do
                            G.E_MANAGER:add_event(Event({
                                trigger = 'after',
                                delay = 0.4,
                                func = function()
                                    play_sound('timpani')
                                    SMODS.add_card({ set = 'Tarot', })                            
                                    card:juice_up(0.3, 0.5)
                                    return true
                                end
                            }))
                        end
                        delay(0.6)
                        
                        if created_consumable then
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_tarot'), colour = G.C.PURPLE})
                        end
                        return true
                    end
                }
            end
        end
    end
}