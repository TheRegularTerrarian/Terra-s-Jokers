SMODS.Joker{ --Administrator
    key = "administrator",
    config = {
        extra = {
            sell_value = 1,
            n = 0,
            y = 0,
            all_jokers = 0
        }
    },
    loc_txt = {
        ['name'] = 'Administrator',
        ['text'] = {
            [1] = 'When a hand is played, if you have over {C:attention}52{} cards',
            [2] = 'in your deck, create a random {C:attention}Consumable{}.',
            [3] = 'After a hand finishes scoring, if you have 2 or more',
            [4] = '{C:attention}Consumables{} give all Jokers {C:attention}$1{} sell value'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 2,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if #G.playing_cards > 52 then
                for i = 1, math.min(1, G.consumeables.config.card_limit - #G.consumeables.cards) do
                    G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.4,
                    func = function()
                        play_sound('timpani')
                        local sets = {'Tarot', 'Planet', 'Spectral'}
                        local random_set = pseudorandom_element(sets, 'random_consumable_set')
                        SMODS.add_card({ set = random_set, soulable = true, })                            
                        card:juice_up(0.3, 0.5)
                        return true
                        end
                    }))
                end
                delay(0.6)
                return {
                    message = created_consumable and localize('k_plus_consumable') or nil
                }
            end
        end
        if context.after and context.cardarea == G.jokers  then
            if #G.consumeables.cards >= 2 then
                return {
                    func = function()
                        for i, target_card in ipairs(G.jokers.cards) do
                            if target_card.set_cost then
                                target_card.ability.extra_value = (card.ability.extra_value or 0) + card.ability.extra.sell_value
                                target_card:set_cost()
                            end
                        end
                        return true
                        end,
                        message = "All Jokers +"..tostring(card.ability.extra.sell_value).." Sell Value"
                    }
                end
            end
        end
}