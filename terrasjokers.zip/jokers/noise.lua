
SMODS.Joker{ --Noise
    key = "noise",
    config = {
        extra = {
            hands0 = 1,
            discards0 = 1,
            hand_size0 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Noise',
        ['text'] = {
            [1] = 'When a {C:attention}Boss Blind{} is selected, lose {C:attention}1{}',
            [2] = 'hand and gain {C:attention}+1{} discard and {C:attention}+1{} hand size'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 6,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.setting_blind  then
            if G.GAME.blind.boss then
                return {
                    
                    func = function()
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(1).." Hands", colour = G.C.RED})
                        
                        G.GAME.round_resets.hands = G.GAME.round_resets.hands - 1
                        ease_hands_played(-1)
                        
                        return true
                    end,
                    extra = {
                        
                        func = function()
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(1).." Discards", colour = G.C.GREEN})
                            
                            G.GAME.round_resets.discards = G.GAME.round_resets.discards + 1
                            ease_discard(1)
                            
                            return true
                        end,
                        colour = G.C.GREEN,
                        extra = {
                            
                            func = function()
                                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(1).." Hand Limit", colour = G.C.BLUE})
                                
                                G.hand:change_size(1)
                                return true
                            end,
                            colour = G.C.WHITE
                        }
                    }
                }
            end
        end
    end
}