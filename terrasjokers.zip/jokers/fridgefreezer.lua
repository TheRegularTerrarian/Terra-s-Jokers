
SMODS.Joker{ --Fridge-Freezer
    key = "fridgefreezer",
    config = {
        extra = {
            mult = 10,
            mod_probability = 2,
            Xmult = 2,
            numerator = 0
        }
    },
    loc_txt = {
        ['name'] = 'Fridge-Freezer',
        ['text'] = {
            [1] = 'When a {C:attention}Lucky{} card is triggered,',
            [2] = 'gain {C:red}+10{} Mult. Doubles all {C:attention}listed{} {C:green}probabilities{}',
            [3] = '(ex: {C:green}1 in 3{} -> {C:green}2 in 3{})'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 6,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' and args.source ~= 'buf' and args.source ~= 'jud' and args.source ~= 'rta' and args.source ~= 'wra' 
            or args.source == 'rif' or args.source == 'sou' or args.source == 'uta'
        )
        and true
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (SMODS.get_enhancements(context.other_card)["m_lucky"] == true and context.other_card.lucky_trigger) then
                return {
                    mult = card.ability.extra.mult
                }
            end
        end
        if context.mod_probability  then
            local numerator, denominator = context.numerator, context.denominator
            numerator = numerator * (card.ability.extra.mod_probability)
            return {
                numerator = numerator, 
                denominator = denominator
            }
        end
        if context.cardarea == G.jokers and context.joker_main  then
            if to_big(#G.jokers.highlighted) == to_big(1) then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            end
        end
    end
}