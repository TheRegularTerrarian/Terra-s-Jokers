SMODS.Joker{ --Skewer
    key = "skewer",
    config = {
        extra = {
            Xmult = 4,
            Xmult2 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Skewer',
        ['text'] = {
            [1] = 'When a card is scored,',
            [2] = 'enhance it to a {C:attention}Mult card{}.',
            [3] = 'If there are 22 {C:attention}Mult cards{}',
            [4] = 'in the deck, gain {X:red,C:white}X4{} Mult'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 4,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if not (SMODS.get_enhancements(context.other_card)["m_mult"] == true) then
                context.other_card:set_ability(G.P_CENTERS.m_mult)
                return {
                    message = "Shished!"
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
                local count = 0
                for _, playing_card in pairs(G.playing_cards or {}) do
                    if SMODS.get_enhancements(playing_card)["m_mult"] == true then
                        count = count + 1
                    end
                end
                return count >= 22
                end)() then
                    return {
                        Xmult = card.ability.extra.Xmult,
                        message = "Skewered!"
                    }
                elseif (function()
                    for i = 1, #G.jokers.cards do
                        if G.jokers.cards[i].config.center.key == "j_terrasjo_ovenleader" then
                            return true
                            end
                        end
                        return false
                        end)() then
                            return {
                                Xmult = card.ability.extra.Xmult2
                            }
                        end
                    end
                end
}