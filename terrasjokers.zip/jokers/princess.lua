
SMODS.Joker{ --Princess
    key = "princess",
    config = {
        extra = {
            dollars = 3,
            mult = 6,
            chips = 33
        }
    },
    loc_txt = {
        ['name'] = 'Princess',
        ['text'] = {
            [1] = 'Played {C:diamond}Diamond{} cards give {C:blue}+33{} Chips',
            [2] = 'and {C:red}+6{} Mult. {C:diamond}Diamond{} cards held',
            [3] = 'in hand give {C:gold}$3{}.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 3,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.hand and context.end_of_round  then
            if context.other_card:is_suit("Diamonds") then
                return {
                    
                    func = function()
                        
                        local current_dollars = G.GAME.dollars
                        local target_dollars = G.GAME.dollars + card.ability.extra.dollars
                        local dollar_value = target_dollars - current_dollars
                        ease_dollars(dollar_value)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.dollars), colour = G.C.MONEY})
                        return true
                    end
                }
            end
        end
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Diamonds") then
                return {
                    mult = card.ability.extra.mult,
                    extra = {
                        chips = card.ability.extra.chips,
                        colour = G.C.CHIPS
                    }
                }
            end
        end
    end
}