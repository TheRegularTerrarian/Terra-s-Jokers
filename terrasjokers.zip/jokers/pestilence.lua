
SMODS.Joker{ --Pestilence
    key = "pestilence",
    config = {
        extra = {
            Xmult = 4,
            levels = 1,
            Xmult2 = 3,
            levels2 = 1,
            Xmult3 = 3,
            levels3 = 1,
            Xmult4 = 3,
            levels4 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Pestilence',
        ['text'] = {
            [1] = 'If played {C:attention}poker hand{} is any type of {C:attention}Flush{},',
                [2] = 'gain {X:red,C:white}X4{} Mult if it is a {C:attention}Flush{} or {X:red,C:white}X3{} Mult',
                    [3] = 'if it\'s a different {C:attention}Flush{} and increase the',
                        [4] = 'level of played {C:attention}poker hand{} by {C:attention}1{}.'
                    },
                    ['unlock'] = {
                        [1] = 'Unlocked by default.'
                    }
                },
                pos = {
                    x = 5,
                    y = 6
                },
                display_size = {
                    w = 71 * 1, 
                    h = 95 * 1
                },
                cost = 20,
                rarity = 3,
                blueprint_compat = true,
                eternal_compat = true,
                perishable_compat = true,
                unlocked = true,
                discovered = false,
                atlas = 'CustomJokers',
                pools = { ["terrasjo_terrasjo_jokers"] = true },
                in_pool = function(self, args)
                    return (
                        not args 
                        or args.source ~= 'sho' and args.source ~= 'buf' and args.source ~= 'jud' and args.source ~= 'rta' and args.source ~= 'sou' and args.source ~= 'wra' 
                        or args.source == 'rif' or args.source == 'uta'
                    )
                    and true
                end,
                
                calculate = function(self, card, context)
                    if context.cardarea == G.jokers and context.joker_main  then
                        if next(context.poker_hands["Flush"]) then
                            local target_hand = (context.scoring_name or "High Card")
                            return {
                                Xmult = card.ability.extra.Xmult,
                                extra = {
                                    level_up = card.ability.extra.levels,
                                    level_up_hand = target_hand,
                                    message = localize('k_level_up_ex'),
                                    colour = G.C.RED
                                }
                            }
                            elseif next(context.poker_hands["Straight Flush"]) then
                                local target_hand2 = (context.scoring_name or "High Card")
                                return {
                                    Xmult = card.ability.extra.Xmult2,
                                    extra = {
                                        level_up = card.ability.extra.levels2,
                                        level_up_hand = target_hand2,
                                        message = localize('k_level_up_ex'),
                                        colour = G.C.RED
                                    }
                                }
                                elseif next(context.poker_hands["Flush House"]) then
                                    local target_hand3 = (context.scoring_name or "High Card")
                                    return {
                                        Xmult = card.ability.extra.Xmult3,
                                        extra = {
                                            level_up = card.ability.extra.levels3,
                                            level_up_hand = target_hand3,
                                            message = localize('k_level_up_ex'),
                                            colour = G.C.RED
                                        }
                                    }
                                    elseif next(context.poker_hands["Flush Five"]) then
                                        local target_hand4 = (context.scoring_name or "High Card")
                                        return {
                                            Xmult = card.ability.extra.Xmult4,
                                            extra = {
                                                level_up = card.ability.extra.levels4,
                                                level_up_hand = target_hand4,
                                                message = localize('k_level_up_ex'),
                                                colour = G.C.RED
                                            }
                                        }
                                    end
                                end
                            end
                        }