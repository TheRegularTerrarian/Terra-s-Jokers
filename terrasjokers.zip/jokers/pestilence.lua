
SMODS.Joker{ --Pestilence
    key = "pestilence",
    config = {
        extra = {
            xmult0 = 4,
            levels0 = 1,
            xmult = 3,
            levels = 1,
            xmult2 = 3,
            levels2 = 1,
            xmult3 = 3,
            levels3 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Pestilence',
        ['text'] = {
            [1] = 'If played {C:attention}poker hand{} is any type of {C:attention}Flush{},',
            [2] = 'gain {X:red,C:white}X4{} Mult if it is a {C:attention}Flush{} or {X:red,C:white}X3{} Mult',
            [3] = 'if it\'s a different {C:attention}Flush{} and increase the',
            [4] = 'level of played {C:attention}poker hand{} by {C:attention}1{}.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terrasjo_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' and args.source ~= 'buf' and args.source ~= 'jud' and args.source ~= 'rta' and args.source ~= 'sou' and args.source ~= 'wra' 
            or args.source == 'rif' or args.source == 'uta'
        )
        and true
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (next(context.poker_hands["Flush"]) and not (next(context.poker_hands["Straight Flush"])) and not (next(context.poker_hands["Flush House"])) and not (next(context.poker_hands["Flush Five"]))) then
                local target_hand = (context.scoring_name or "High Card")
                level_up_hand(card, target_hand, true, 1)
                return {
                    Xmult = 4,
                    extra = {
                        message = localize('k_level_up_ex'),
                        colour = G.C.RED
                    }
                }
            elseif next(context.poker_hands["Straight Flush"]) then
                local target_hand2 = (context.scoring_name or "High Card")
                level_up_hand(card, target_hand2, true, 1)
                return {
                    Xmult = 3,
                    extra = {
                        message = localize('k_level_up_ex'),
                        colour = G.C.RED
                    }
                }
            elseif next(context.poker_hands["Flush House"]) then
                local target_hand3 = (context.scoring_name or "High Card")
                level_up_hand(card, target_hand3, true, 1)
                return {
                    Xmult = 3,
                    extra = {
                        message = localize('k_level_up_ex'),
                        colour = G.C.RED
                    }
                }
            elseif next(context.poker_hands["Flush Five"]) then
                local target_hand4 = (context.scoring_name or "High Card")
                level_up_hand(card, target_hand4, true, 1)
                return {
                    Xmult = 3,
                    extra = {
                        message = localize('k_level_up_ex'),
                        colour = G.C.RED
                    }
                }
            end
        end
    end
}

local check_for_buy_space_ref = G.FUNCS.check_for_buy_space
G.FUNCS.check_for_buy_space = function(card)
    if card.config.center.key == "j_terrasjo_pestilence" then -- ignore slot limit when bought
        return true
    end
    return check_for_buy_space_ref(card)
end

local can_select_card_ref = G.FUNCS.can_select_card
G.FUNCS.can_select_card = function(e)
    	if e.config.ref_table.config.center.key == "j_terrasjo_pestilence" then
        		e.config.colour = G.C.GREEN
        		e.config.button = "use_card"
    	else
        		can_select_card_ref(e)
    	end
end