
SMODS.Joker{ --Cold Storage
    key = "coldstorage",
    config = {
        extra = {
            chips0 = 40,
            chips = 80,
            chips2 = 120,
            chips3 = 160,
            chips4 = 200,
            xmult0 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Cold Storage',
        ['text'] = {
            [1] = '{C:blue}+40{} Chips. {C:blue}+40{} additional Chips per {C:blue}Hands{} under 4.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 9,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if to_big(G.GAME.current_round.hands_left) >= to_big(4) then
                return {
                    chips = 40
                }
            elseif to_big(G.GAME.current_round.hands_left) == to_big(3) then
                return {
                    chips = 80
                }
            elseif to_big(G.GAME.current_round.hands_left) == to_big(2) then
                return {
                    chips = 120
                }
            elseif to_big(G.GAME.current_round.hands_left) == to_big(1) then
                return {
                    chips = 160
                }
            elseif to_big(G.GAME.current_round.hands_left) == to_big(1) then
                return {
                    chips = 200
                }
            elseif #G.jokers.highlighted > 0 and G.jokers.highlighted[1].config.center.key == "j_terrasjo_ovenleader" then
                return {
                    Xmult = 2
                }
            end
        end
    end
}