SMODS.Joker{ --Cold Storage
    key = "coldstorage",
    config = {
        extra = {
            chips = 40,
            chips2 = 80,
            chips3 = 120,
            chips4 = 160,
            chips5 = 200
        }
    },
    loc_txt = {
        ['name'] = 'Cold Storage',
        ['text'] = {
            [1] = '{C:blue}+40{} Chips. {C:blue}+40{} additional Chips per {C:blue}Hands{} under 4.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 9,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["terrasjo_terras_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if G.GAME.current_round.hands_left >= 4 then
                return {
                    chips = card.ability.extra.chips
                }
            elseif G.GAME.current_round.hands_left == 3 then
                return {
                    chips = card.ability.extra.chips2
                }
            elseif G.GAME.current_round.hands_left == 2 then
                return {
                    chips = card.ability.extra.chips3
                }
            elseif G.GAME.current_round.hands_left == 1 then
                return {
                    chips = card.ability.extra.chips4
                }
            elseif G.GAME.current_round.hands_left == 0 then
                return {
                    chips = card.ability.extra.chips5
                }
            end
        end
    end
}