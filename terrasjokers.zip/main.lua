SMODS.Atlas({
    key = "CustomJokers", 
    path = "CustomJokers.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomDecks", 
    path = "CustomDecks.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

local NFS = require("nativefs")
to_big = to_big or function(a) return a end
lenient_bignum = lenient_bignum or function(a) return a end

local jokerIndexList = {47,43,44,52,65,28,29,61,40,14,46,74,6,72,30,13,2,64,38,12,67,20,63,4,25,36,49,8,62,68,11,27,1,16,32,45,50,19,53,22,33,31,70,58,39,59,17,71,23,41,3,34,77,9,37,60,15,10,57,56,48,73,76,21,42,35,7,24,51,55,54,5,26,69,75,66,18}

local function load_jokers_folder()
    local mod_path = SMODS.current_mod.path
    local jokers_path = mod_path .. "/jokers"
    local files = NFS.getDirectoryItemsInfo(jokers_path)
    for i = 1, #jokerIndexList do
        local file_name = files[jokerIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("jokers/" .. file_name))()
        end
    end
end


local deckIndexList = {1,2}

local function load_decks_folder()
    local mod_path = SMODS.current_mod.path
    local decks_path = mod_path .. "/decks"
    local files = NFS.getDirectoryItemsInfo(decks_path)
    for i = 1, #deckIndexList do
        local file_name = files[deckIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("decks/" .. file_name))()
        end
    end
end

load_jokers_folder()
load_decks_folder()
SMODS.ObjectType({
    key = "terrasjo_food",
    cards = {
        ["j_gros_michel"] = true,
        ["j_egg"] = true,
        ["j_ice_cream"] = true,
        ["j_cavendish"] = true,
        ["j_turtle_bean"] = true,
        ["j_diet_cola"] = true,
        ["j_popcorn"] = true,
        ["j_ramen"] = true,
        ["j_selzer"] = true
    },
})

SMODS.ObjectType({
    key = "terrasjo_terras_jokers",
    cards = {
        ["j_terrasjo_administrator"] = true,
        ["j_terrasjo_airfryer"] = true,
        ["j_terrasjo_archmage"] = true,
        ["j_terrasjo_armsdealer"] = true,
        ["j_terrasjo_baker"] = true,
        ["j_terrasjo_blender"] = true,
        ["j_terrasjo_blight"] = true,
        ["j_terrasjo_broker"] = true,
        ["j_terrasjo_bulwark"] = true,
        ["j_terrasjo_caterer"] = true,
        ["j_terrasjo_ceo"] = true,
        ["j_terrasjo_chef"] = true,
        ["j_terrasjo_coldstorage"] = true,
        ["j_terrasjo_corrupter"] = true,
        ["j_terrasjo_darkmage"] = true,
        ["j_terrasjo_demolitionist"] = true,
        ["j_terrasjo_director"] = true,
        ["j_terrasjo_dreamweaver"] = true,
        ["j_terrasjo_dryad"] = true,
        ["j_terrasjo_empressoflight"] = true,
        ["j_terrasjo_enchanter"] = true,
        ["j_terrasjo_executive"] = true,
        ["j_terrasjo_frauder"] = true,
        ["j_terrasjo_fridge"] = true,
        ["j_terrasjo_garlicbread"] = true,
        ["j_terrasjo_goblintinkerer"] = true,
        ["j_terrasjo_guide"] = true,
        ["j_terrasjo_gunsmith"] = true,
        ["j_terrasjo_hexmaster"] = true,
        ["j_terrasjo_illusionist"] = true,
        ["j_terrasjo_interrogator"] = true,
        ["j_terrasjo_jinx"] = true,
        ["j_terrasjo_kettle"] = true,
        ["j_terrasjo_kingslime"] = true,
        ["j_terrasjo_knifeblock"] = true,
        ["j_terrasjo_lunaticcultist"] = true,
        ["j_terrasjo_medusa"] = true,
        ["j_terrasjo_merchant"] = true,
        ["j_terrasjo_microwave"] = true,
        ["j_terrasjo_necromancer"] = true,
        ["j_terrasjo_noise"] = true,
        ["j_terrasjo_nurse"] = true,
        ["j_terrasjo_painter"] = true,
        ["j_terrasjo_plaguebearer"] = true,
        ["j_terrasjo_poisoner"] = true,
        ["j_terrasjo_potionmaster"] = true,
        ["j_terrasjo_princess"] = true,
        ["j_terrasjo_queenslime"] = true,
        ["j_terrasjo_ritualist"] = true,
        ["j_terrasjo_rollingpin"] = true,
        ["j_terrasjo_saboteur"] = true,
        ["j_terrasjo_security"] = true,
        ["j_terrasjo_sink"] = true,
        ["j_terrasjo_skewer"] = true,
        ["j_terrasjo_soulcollector"] = true,
        ["j_terrasjo_suppressor"] = true,
        ["j_terrasjo_surveillance"] = true,
        ["j_terrasjo_tactician"] = true,
        ["j_terrasjo_tavernkeeper"] = true,
        ["j_terrasjo_thedestroyer"] = true,
        ["j_terrasjo_toaster"] = true,
        ["j_terrasjo_voodoomaster"] = true,
        ["j_terrasjo_waiter"] = true,
        ["j_terrasjo_wildling"] = true,
        ["j_terrasjo_witch"] = true
    },
})

SMODS.ObjectType({
    key = "terrasjo_terrasjo_jokers",
    cards = {
        ["j_terrasjo_archmage"] = true,
        ["j_terrasjo_baker"] = true,
        ["j_terrasjo_blight"] = true,
        ["j_terrasjo_bulwark"] = true,
        ["j_terrasjo_casanova"] = true,
        ["j_terrasjo_conjurer"] = true,
        ["j_terrasjo_death"] = true,
        ["j_terrasjo_dreamweaver"] = true,
        ["j_terrasjo_enchanter"] = true,
        ["j_terrasjo_famine"] = true,
        ["j_terrasjo_hexmaster"] = true,
        ["j_terrasjo_illusionist"] = true,
        ["j_terrasjo_jinx"] = true,
        ["j_terrasjo_medusa"] = true,
        ["j_terrasjo_necromancer"] = true,
        ["j_terrasjo_pestilence"] = true,
        ["j_terrasjo_plaguebearer"] = true,
        ["j_terrasjo_poisoner"] = true,
        ["j_terrasjo_potionmaster"] = true,
        ["j_terrasjo_ritualist"] = true,
        ["j_terrasjo_soulcollector"] = true,
        ["j_terrasjo_tactician"] = true,
        ["j_terrasjo_voodoomaster"] = true,
        ["j_terrasjo_war"] = true,
        ["j_terrasjo_wildling"] = true,
        ["j_terrasjo_witch"] = true
    },
})

SMODS.ObjectType({
    key = "terrasjo_Coven_Jokers",
    cards = {
        ["j_terrasjo_archmage"] = true,
        ["j_terrasjo_blight"] = true,
        ["j_terrasjo_bulwark"] = true,
        ["j_terrasjo_casanova"] = true,
        ["j_terrasjo_conjurer"] = true,
        ["j_terrasjo_dreamweaver"] = true,
        ["j_terrasjo_enchanter"] = true,
        ["j_terrasjo_hexmaster"] = true,
        ["j_terrasjo_illusionist"] = true,
        ["j_terrasjo_jinx"] = true,
        ["j_terrasjo_medusa"] = true,
        ["j_terrasjo_necromancer"] = true,
        ["j_terrasjo_poisoner"] = true,
        ["j_terrasjo_potionmaster"] = true,
        ["j_terrasjo_ritualist"] = true,
        ["j_terrasjo_voodoomaster"] = true,
        ["j_terrasjo_wildling"] = true,
        ["j_terrasjo_witch"] = true
    },
})


SMODS.current_mod.optional_features = function()
    return {
        cardareas = {} 
    }
end