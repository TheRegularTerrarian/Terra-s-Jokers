SMODS.Atlas({
    key = "CustomJokers", 
    path = "CustomJokers.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

local NFS = require("nativefs")
to_big = to_big or function(a) return a end
lenient_bignum = lenient_bignum or function(a) return a end

local jokerIndexList = {48,44,45,53,66,29,30,62,41,14,47,75,6,73,31,13,2,65,39,12,68,20,64,4,26,37,50,8,63,69,11,28,1,16,33,46,51,19,23,54,22,34,32,71,59,40,60,17,72,24,42,3,35,78,9,38,61,15,10,58,57,49,74,77,21,43,36,7,25,52,56,55,5,27,70,76,67,18}

local function load_jokers_folder()
    local mod_path = SMODS.current_mod.path
    local jokers_path = mod_path .. "/jokers"
    local files = NFS.getDirectoryItemsInfo(jokers_path)
    for i = 1, #jokerIndexList do
        local file_name = files[jokerIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("jokers/" .. file_name))()
        end
    end
end

load_jokers_folder()
SMODS.ObjectType({
    key = "terrasjo_food",
    cards = {
        ["j_gros_michel"] = true,
        ["j_egg"] = true,
        ["j_ice_cream"] = true,
        ["j_cavendish"] = true,
        ["j_turtle_bean"] = true,
        ["j_diet_cola"] = true,
        ["j_popcorn"] = true,
        ["j_ramen"] = true,
        ["j_selzer"] = true
    },
})

SMODS.ObjectType({
    key = "terrasjo_terras_jokers",
    cards = {
        ["j_terrasjo_administrator"] = true,
        ["j_terrasjo_airfryer"] = true,
        ["j_terrasjo_archmage"] = true,
        ["j_terrasjo_armsdealer"] = true,
        ["j_terrasjo_baker"] = true,
        ["j_terrasjo_blender"] = true,
        ["j_terrasjo_blight"] = true,
        ["j_terrasjo_broker"] = true,
        ["j_terrasjo_bulwark"] = true,
        ["j_terrasjo_caterer"] = true,
        ["j_terrasjo_ceo"] = true,
        ["j_terrasjo_chef"] = true,
        ["j_terrasjo_coldstorage"] = true,
        ["j_terrasjo_corrupter"] = true,
        ["j_terrasjo_darkmage"] = true,
        ["j_terrasjo_demolitionist"] = true,
        ["j_terrasjo_director"] = true,
        ["j_terrasjo_dreamweaver"] = true,
        ["j_terrasjo_dryad"] = true,
        ["j_terrasjo_dyetrader"] = true,
        ["j_terrasjo_empressoflight"] = true,
        ["j_terrasjo_enchanter"] = true,
        ["j_terrasjo_executive"] = true,
        ["j_terrasjo_frauder"] = true,
        ["j_terrasjo_fridge"] = true,
        ["j_terrasjo_garlicbread"] = true,
        ["j_terrasjo_goblintinkerer"] = true,
        ["j_terrasjo_guide"] = true,
        ["j_terrasjo_gunsmith"] = true,
        ["j_terrasjo_hexmaster"] = true,
        ["j_terrasjo_illusionist"] = true,
        ["j_terrasjo_interrogator"] = true,
        ["j_terrasjo_jinx"] = true,
        ["j_terrasjo_kettle"] = true,
        ["j_terrasjo_kingslime"] = true,
        ["j_terrasjo_knifeblock"] = true,
        ["j_terrasjo_lunaticcultist"] = true,
        ["j_terrasjo_medusa"] = true,
        ["j_terrasjo_merchant"] = true,
        ["j_terrasjo_microwave"] = true,
        ["j_terrasjo_necromancer"] = true,
        ["j_terrasjo_noise"] = true,
        ["j_terrasjo_nurse"] = true,
        ["j_terrasjo_painter"] = true,
        ["j_terrasjo_plaguebearer"] = true,
        ["j_terrasjo_poisoner"] = true,
        ["j_terrasjo_potionmaster"] = true,
        ["j_terrasjo_princess"] = true,
        ["j_terrasjo_queenslime"] = true,
        ["j_terrasjo_ritualist"] = true,
        ["j_terrasjo_rollingpin"] = true,
        ["j_terrasjo_saboteur"] = true,
        ["j_terrasjo_security"] = true,
        ["j_terrasjo_sink"] = true,
        ["j_terrasjo_skewer"] = true,
        ["j_terrasjo_soulcollector"] = true,
        ["j_terrasjo_suppressor"] = true,
        ["j_terrasjo_surveillance"] = true,
        ["j_terrasjo_tactician"] = true,
        ["j_terrasjo_tavernkeeper"] = true,
        ["j_terrasjo_thedestroyer"] = true,
        ["j_terrasjo_toaster"] = true,
        ["j_terrasjo_voodoomaster"] = true,
        ["j_terrasjo_waiter"] = true,
        ["j_terrasjo_wildling"] = true,
        ["j_terrasjo_witch"] = true
    },
})

SMODS.ObjectType({
    key = "terrasjo_terrasjo_jokers",
    cards = {
        ["j_terrasjo_archmage"] = true,
        ["j_terrasjo_baker"] = true,
        ["j_terrasjo_blight"] = true,
        ["j_terrasjo_bulwark"] = true,
        ["j_terrasjo_casanova"] = true,
        ["j_terrasjo_conjurer"] = true,
        ["j_terrasjo_death"] = true,
        ["j_terrasjo_dreamweaver"] = true,
        ["j_terrasjo_enchanter"] = true,
        ["j_terrasjo_famine"] = true,
        ["j_terrasjo_hexmaster"] = true,
        ["j_terrasjo_illusionist"] = true,
        ["j_terrasjo_jinx"] = true,
        ["j_terrasjo_medusa"] = true,
        ["j_terrasjo_necromancer"] = true,
        ["j_terrasjo_pestilence"] = true,
        ["j_terrasjo_plaguebearer"] = true,
        ["j_terrasjo_poisoner"] = true,
        ["j_terrasjo_potionmaster"] = true,
        ["j_terrasjo_ritualist"] = true,
        ["j_terrasjo_soulcollector"] = true,
        ["j_terrasjo_tactician"] = true,
        ["j_terrasjo_voodoomaster"] = true,
        ["j_terrasjo_war"] = true,
        ["j_terrasjo_wildling"] = true,
        ["j_terrasjo_witch"] = true
    },
})

SMODS.ObjectType({
    key = "terrasjo_Coven_Jokers",
    cards = {
        ["j_terrasjo_archmage"] = true,
        ["j_terrasjo_blight"] = true,
        ["j_terrasjo_bulwark"] = true,
        ["j_terrasjo_casanova"] = true,
        ["j_terrasjo_conjurer"] = true,
        ["j_terrasjo_dreamweaver"] = true,
        ["j_terrasjo_enchanter"] = true,
        ["j_terrasjo_hexmaster"] = true,
        ["j_terrasjo_illusionist"] = true,
        ["j_terrasjo_jinx"] = true,
        ["j_terrasjo_medusa"] = true,
        ["j_terrasjo_necromancer"] = true,
        ["j_terrasjo_poisoner"] = true,
        ["j_terrasjo_potionmaster"] = true,
        ["j_terrasjo_ritualist"] = true,
        ["j_terrasjo_voodoomaster"] = true,
        ["j_terrasjo_wildling"] = true,
        ["j_terrasjo_witch"] = true
    },
})