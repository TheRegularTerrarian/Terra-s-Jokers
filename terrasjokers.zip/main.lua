SMODS.Atlas({
    key = "CustomJokers", 
    path = "CustomJokers.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

local NFS = require("nativefs")
to_big = to_big or function(a) return a end
lenient_bignum = lenient_bignum or function(a) return a end

local jokerIndexList = {43,39,40,48,60,25,26,56,36,12,42,69,4,67,27,11,1,59,35,10,62,18,58,2,22,33,45,6,57,63,9,24,14,29,41,46,17,49,19,30,28,65,54,15,66,20,37,31,72,7,34,55,13,8,53,52,44,68,71,38,32,5,21,47,51,50,3,23,64,70,61,16}

local function load_jokers_folder()
    local mod_path = SMODS.current_mod.path
    local jokers_path = mod_path .. "/jokers"
    local files = NFS.getDirectoryItemsInfo(jokers_path)
    for i = 1, #jokerIndexList do
        local file_name = files[jokerIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("jokers/" .. file_name))()
        end
    end
end

load_jokers_folder()
SMODS.ObjectType({
    key = "terrasjo_food",
    cards = {
        ["j_gros_michel"] = true,
        ["j_egg"] = true,
        ["j_ice_cream"] = true,
        ["j_cavendish"] = true,
        ["j_turtle_bean"] = true,
        ["j_diet_cola"] = true,
        ["j_popcorn"] = true,
        ["j_ramen"] = true,
        ["j_selzer"] = true
    },
})

SMODS.ObjectType({
    key = "terrasjo_terras_jokers",
    cards = {
        ["j_terrasjo_airfryer"] = true,
        ["j_terrasjo_armsdealer"] = true,
        ["j_terrasjo_baker"] = true,
        ["j_terrasjo_blender"] = true,
        ["j_terrasjo_blight"] = true,
        ["j_terrasjo_broker"] = true,
        ["j_terrasjo_bulwark"] = true,
        ["j_terrasjo_caterer"] = true,
        ["j_terrasjo_ceo"] = true,
        ["j_terrasjo_chef"] = true,
        ["j_terrasjo_coldstorage"] = true,
        ["j_terrasjo_corrupter"] = true,
        ["j_terrasjo_darkmage"] = true,
        ["j_terrasjo_demolitionist"] = true,
        ["j_terrasjo_director"] = true,
        ["j_terrasjo_dryad"] = true,
        ["j_terrasjo_empressoflight"] = true,
        ["j_terrasjo_enchanter"] = true,
        ["j_terrasjo_executive"] = true,
        ["j_terrasjo_frauder"] = true,
        ["j_terrasjo_fridge"] = true,
        ["j_terrasjo_garlicbread"] = true,
        ["j_terrasjo_goblintinkerer"] = true,
        ["j_terrasjo_guide"] = true,
        ["j_terrasjo_gunsmith"] = true,
        ["j_terrasjo_hexmaster"] = true,
        ["j_terrasjo_illusionist"] = true,
        ["j_terrasjo_interrogator"] = true,
        ["j_terrasjo_jinx"] = true,
        ["j_terrasjo_kettle"] = true,
        ["j_terrasjo_knifeblock"] = true,
        ["j_terrasjo_lunaticcultist"] = true,
        ["j_terrasjo_medusa"] = true,
        ["j_terrasjo_merchant"] = true,
        ["j_terrasjo_microwave"] = true,
        ["j_terrasjo_necromancer"] = true,
        ["j_terrasjo_noise"] = true,
        ["j_terrasjo_nurse"] = true,
        ["j_terrasjo_painter"] = true,
        ["j_terrasjo_plaguebearer"] = true,
        ["j_terrasjo_poisoner"] = true,
        ["j_terrasjo_potionmaster"] = true,
        ["j_terrasjo_princess"] = true,
        ["j_terrasjo_ritualist"] = true,
        ["j_terrasjo_rollingpin"] = true,
        ["j_terrasjo_saboteur"] = true,
        ["j_terrasjo_security"] = true,
        ["j_terrasjo_sink"] = true,
        ["j_terrasjo_skewer"] = true,
        ["j_terrasjo_soulcollector"] = true,
        ["j_terrasjo_suppressor"] = true,
        ["j_terrasjo_surveillance"] = true,
        ["j_terrasjo_tactician"] = true,
        ["j_terrasjo_tavernkeeper"] = true,
        ["j_terrasjo_thedestroyer"] = true,
        ["j_terrasjo_toaster"] = true,
        ["j_terrasjo_voodoomaster"] = true,
        ["j_terrasjo_waiter"] = true,
        ["j_terrasjo_wildling"] = true,
        ["j_terrasjo_witch"] = true
    },
})

SMODS.ObjectType({
    key = "terrasjo_terrasjo_jokers",
    cards = {
        ["j_terrasjo_baker"] = true,
        ["j_terrasjo_blight"] = true,
        ["j_terrasjo_bulwark"] = true,
        ["j_terrasjo_casanova"] = true,
        ["j_terrasjo_conjurer"] = true,
        ["j_terrasjo_death"] = true,
        ["j_terrasjo_enchanter"] = true,
        ["j_terrasjo_famine"] = true,
        ["j_terrasjo_hexmaster"] = true,
        ["j_terrasjo_illusionist"] = true,
        ["j_terrasjo_jinx"] = true,
        ["j_terrasjo_medusa"] = true,
        ["j_terrasjo_necromancer"] = true,
        ["j_terrasjo_pestilence"] = true,
        ["j_terrasjo_plaguebearer"] = true,
        ["j_terrasjo_poisoner"] = true,
        ["j_terrasjo_potionmaster"] = true,
        ["j_terrasjo_ritualist"] = true,
        ["j_terrasjo_soulcollector"] = true,
        ["j_terrasjo_tactician"] = true,
        ["j_terrasjo_voodoomaster"] = true,
        ["j_terrasjo_war"] = true,
        ["j_terrasjo_wildling"] = true,
        ["j_terrasjo_witch"] = true
    },
})

SMODS.ObjectType({
    key = "terrasjo_Coven_Jokers",
    cards = {
        ["j_terrasjo_blight"] = true,
        ["j_terrasjo_bulwark"] = true,
        ["j_terrasjo_casanova"] = true,
        ["j_terrasjo_conjurer"] = true,
        ["j_terrasjo_enchanter"] = true,
        ["j_terrasjo_hexmaster"] = true,
        ["j_terrasjo_illusionist"] = true,
        ["j_terrasjo_jinx"] = true,
        ["j_terrasjo_medusa"] = true,
        ["j_terrasjo_necromancer"] = true,
        ["j_terrasjo_poisoner"] = true,
        ["j_terrasjo_potionmaster"] = true,
        ["j_terrasjo_ritualist"] = true,
        ["j_terrasjo_voodoomaster"] = true,
        ["j_terrasjo_wildling"] = true,
        ["j_terrasjo_witch"] = true
    },
})


SMODS.current_mod.optional_features = function()
    return {
        cardareas = {} 
    }
end